package com.example.pet_ultima.data.repository

import com.example.pet_ultima.data.db.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class PetRepository(private val db: AppDatabase) {
    // Users
    fun getAllUsers(): Flow<List<User>> = db.userDao().getAllUsers()
    suspend fun getUserById(id: String): User? = db.userDao().getUserById(id)
    suspend fun getUserByUsername(username: String): User? = db.userDao().getUserByUsername(username)
    suspend fun insertUser(user: User) = db.userDao().insertUser(user)
    suspend fun updateUser(user: User) = db.userDao().updateUser(user)
    suspend fun deleteUser(id: String) = db.userDao().deleteUser(id)
    suspend fun getUserCount(): Int = db.userDao().getUserCount()

    // Pets
    fun getPetsForUser(userId: String): Flow<List<Pet>> = db.petDao().getPetsForUser(userId)
    fun getAllPets(): Flow<List<Pet>> = db.petDao().getAllPets()
    suspend fun getPetById(id: String): Pet? = db.petDao().getPetById(id)
    suspend fun insertPet(pet: Pet) = db.petDao().insertPet(pet)
    suspend fun updatePet(pet: Pet) = db.petDao().updatePet(pet)
    suspend fun deletePet(id: String) = db.petDao().deletePet(id)

    // Pet shares
    fun getSharedUserIds(petId: String): Flow<List<String>> = db.petShareDao().getSharedUserIds(petId)
    fun getSharesForPet(petId: String): Flow<List<PetShare>> = db.petShareDao().getSharesForPet(petId)
    suspend fun addShare(petId: String, userId: String) = db.petShareDao().insertShare(PetShare(petId, userId))
    suspend fun removeShare(petId: String, userId: String) = db.petShareDao().removeShare(petId, userId)
    suspend fun removeAllShares(petId: String) = db.petShareDao().removeAllSharesForPet(petId)

    // Geofences
    fun getGeofencesForUser(userId: String): Flow<List<Geofence>> = db.geofenceDao().getGeofencesForUser(userId)
    fun getAllGeofences(): Flow<List<Geofence>> = db.geofenceDao().getAllGeofences()
    fun getGeofencesByPet(petId: String): Flow<List<Geofence>> = db.geofenceDao().getGeofencesByPet(petId)
    suspend fun getGeofenceById(id: String): Geofence? = db.geofenceDao().getGeofenceById(id)
    suspend fun insertGeofence(g: Geofence) = db.geofenceDao().insertGeofence(g)
    suspend fun updateGeofence(g: Geofence) = db.geofenceDao().updateGeofence(g)
    suspend fun deleteGeofence(id: String) = db.geofenceDao().deleteGeofence(id)
    suspend fun getGeofenceCountForPet(petId: String): Int = db.geofenceDao().getGeofenceCountForPet(petId)

    // Alerts
    fun getAllAlerts(): Flow<List<GeofenceAlert>> = db.geofenceAlertDao().getAllAlerts()
    fun getUnreadCount(): Flow<Int> = db.geofenceAlertDao().getUnreadCount()
    suspend fun insertAlert(alert: GeofenceAlert) = db.geofenceAlertDao().insertAlert(alert)
    suspend fun markAlertAsRead(id: String) = db.geofenceAlertDao().markAsRead(id)
    suspend fun markAllAlertsAsRead() = db.geofenceAlertDao().markAllAsRead()

    // Location
    fun getHistoryForPet(petId: String): Flow<List<LocationHistory>> = db.locationHistoryDao().getHistoryForPet(petId)
    suspend fun insertLocation(loc: LocationHistory) = db.locationHistoryDao().insertLocation(loc)
    suspend fun clearHistoryForPet(petId: String) = db.locationHistoryDao().clearHistoryForPet(petId)

    // SMS
    fun getSmsLogsForPet(petId: String): Flow<List<SmsLog>> = db.smsLogDao().getLogsForPet(petId)
    fun getSmsLogsByPhone(phone: String): Flow<List<SmsLog>> = db.smsLogDao().getAllLogs().map { list: List<SmsLog> ->
        list.filter { it.message.contains(phone) }
    }
    fun getAllSmsLogs(): Flow<List<SmsLog>> = db.smsLogDao().getAllLogs()
    suspend fun insertSmsLog(log: SmsLog) = db.smsLogDao().insertLog(log)

    // Trackers
    fun getAllTrackers(): Flow<List<Tracker>> = db.trackerDao().getAllTrackers()
    suspend fun insertTracker(tracker: Tracker) = db.trackerDao().insertTracker(tracker)
    suspend fun updateTracker(tracker: Tracker) = db.trackerDao().updateTracker(tracker)
    suspend fun deleteTracker(id: String) = db.trackerDao().deleteTracker(id)
}
