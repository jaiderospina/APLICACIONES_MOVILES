package com.example.pet_ultima.util

object Gf07Commands {
    /** Request current location once */
    fun requestLocation(chipPassword: String = "123456") = "${chipPassword}dw"

    /** Start auto-tracking every ~10 min */
    fun startTracking(chipPassword: String = "123456") = "${chipPassword} begin"

    /** Stop auto-tracking */
    fun stopTracking(chipPassword: String = "123456") = "${chipPassword} stop"

    /** Set tracking interval in seconds (min 10s, recommended 600) */
    fun setInterval(seconds: Int, chipPassword: String = "123456") = "${chipPassword} t${seconds}s"

    /** Reset/reboot the chip */
    fun reset(chipPassword: String = "123456") = "${chipPassword} reset"

    /** Change chip password */
    fun changePassword(newPwd: String, chipPassword: String = "123456") = "${chipPassword} password${newPwd}"

    /** Parse Google Maps link from GF-07 SMS response.
     *  Typical response: "http://maps.google.com/maps?q=4.607,-74.081" */
    fun parseLocation(smsBody: String): Pair<Double, Double>? {
        val regex = Regex("""[?&]q=([-\d.]+),([-\d.]+)""")
        val match = regex.find(smsBody) ?: return null
        val lat = match.groupValues[1].toDoubleOrNull() ?: return null
        val lng = match.groupValues[2].toDoubleOrNull() ?: return null
        return Pair(lat, lng)
    }
}
