package com.example.pet_ultima.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "pet_shares", primaryKeys = ["petId", "sharedWithUserId"])
data class PetShare(
    val petId: String,
    val sharedWithUserId: String,
    val createdAt: Long = System.currentTimeMillis()
)
