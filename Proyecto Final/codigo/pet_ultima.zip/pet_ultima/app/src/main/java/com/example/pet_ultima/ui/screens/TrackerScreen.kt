package com.example.pet_ultima.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.pet_ultima.data.db.*
import com.example.pet_ultima.sms.Gf07Commands
import com.example.pet_ultima.viewmodel.PetViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrackerScreen(vm: PetViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val pets by vm.pets.collectAsState()
    val trackers by vm.trackers.collectAsState(initial = emptyList<Tracker>())
    var showAddDialog by remember { mutableStateOf(false) }
    var selectedTracker by remember { mutableStateOf<Tracker?>(null) }

    val smsPerm = ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED
    val smsLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}

    LaunchedEffect(Unit) {
        if (!smsPerm) smsLauncher.launch(Manifest.permission.SEND_SMS)
    }

    if (showAddDialog) {
        TrackerFormDialog(
            pets = pets,
            onDismiss = { showAddDialog = false },
            onSave = { tracker -> vm.saveTracker(tracker); showAddDialog = false }
        )
    }

    selectedTracker?.let { tracker ->
        TrackerControlDialog(
            tracker = tracker,
            vm = vm,
            onDismiss = { selectedTracker = null }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Trackers GF-07") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Volver") } },
                actions = { IconButton(onClick = { showAddDialog = true }) { Icon(Icons.Default.Add, "Agregar") } }
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            if (!smsPerm) {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                ) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.Warning, null, tint = MaterialTheme.colorScheme.onErrorContainer)
                        Column {
                            Text("Permiso de SMS requerido", fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onErrorContainer)
                            Text("Necesario para controlar el chip GF-07",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onErrorContainer)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
            }

            if (trackers.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("📡", fontSize = 56.sp)
                        Spacer(Modifier.height(8.dp))
                        Text("Sin trackers configurados", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(4.dp))
                        Text("Agrega el número SIM de tu chip GF-07",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(16.dp))
                        Button(onClick = { showAddDialog = true }, shape = RoundedCornerShape(14.dp)) {
                            Icon(Icons.Default.Add, null, Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Agregar tracker")
                        }
                    }
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(trackers, key = { it.id }) { tracker ->
                        val pet = pets.find { it.id == tracker.petId }
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Column(Modifier.fillMaxWidth().padding(14.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Surface(shape = RoundedCornerShape(12.dp),
                                        color = if (tracker.isActive) MaterialTheme.colorScheme.primaryContainer
                                        else MaterialTheme.colorScheme.outline.copy(alpha = 0.1f),
                                        modifier = Modifier.size(48.dp)) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text("📡", fontSize = 22.sp)
                                        }
                                    }
                                    Column(Modifier.weight(1f)) {
                                        Text(tracker.name, fontWeight = FontWeight.SemiBold)
                                        Text(tracker.phoneNumber, style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text("Mascota: ${pet?.name ?: "—"}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    IconButton(onClick = { selectedTracker = tracker }) {
                                        Icon(Icons.Default.SettingsRemote, "Controlar",
                                            tint = MaterialTheme.colorScheme.primary)
                                    }
                                    IconButton(onClick = { vm.deleteTracker(tracker.id) }) {
                                        Icon(Icons.Default.Delete, "Eliminar",
                                            tint = MaterialTheme.colorScheme.error)
                                    }
                                }

                                if (tracker.lastCommand.isNotBlank()) {
                                    Spacer(Modifier.height(8.dp))
                                    HorizontalDivider()
                                    Spacer(Modifier.height(6.dp))
                                    Text("Último: ${tracker.lastCommand}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TrackerControlDialog(tracker: Tracker, vm: PetViewModel, onDismiss: () -> Unit) {
    val logs by vm.getLogsForTracker(tracker.phoneNumber).collectAsState(initial = emptyList<SmsLog>())
    val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    var customCmd by remember { mutableStateOf("") }

    fun send(cmd: String) {
        vm.sendSmsCommand(tracker.phoneNumber, cmd)
        vm.updateTracker(tracker.copy(lastCommand = cmd, lastCommandAt = System.currentTimeMillis()))
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("📡")
                Text(tracker.name)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(tracker.phoneNumber, style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)

                // Quick command buttons
                Text("Comandos rápidos", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { send(Gf07Commands.requestLocation(tracker.chipPassword)) },
                        modifier = Modifier.weight(1f), shape = RoundedCornerShape(10.dp)) {
                        Text("📍 Ubicación", style = MaterialTheme.typography.labelSmall)
                    }
                    Button(onClick = { send(Gf07Commands.startTracking(tracker.chipPassword)) },
                        modifier = Modifier.weight(1f), shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary)) {
                        Text("▶ Iniciar", style = MaterialTheme.typography.labelSmall)
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { send(Gf07Commands.stopTracking(tracker.chipPassword)) },
                        modifier = Modifier.weight(1f), shape = RoundedCornerShape(10.dp)) {
                        Text("⏹ Detener", style = MaterialTheme.typography.labelSmall)
                    }
                    OutlinedButton(onClick = { send(Gf07Commands.setInterval(1, tracker.chipPassword)) },
                        modifier = Modifier.weight(1f), shape = RoundedCornerShape(10.dp)) {
                        Text("⏱ Cada 1min", style = MaterialTheme.typography.labelSmall)
                    }
                }

                // Custom command
                OutlinedTextField(
                    value = customCmd, onValueChange = { customCmd = it },
                    label = { Text("Comando personalizado") },
                    modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(10.dp),
                    singleLine = true,
                    trailingIcon = {
                        IconButton(onClick = { if (customCmd.isNotBlank()) { send(customCmd); customCmd = "" } }) {
                            Icon(Icons.Default.Send, "Enviar")
                        }
                    }
                )

                // SMS log
                if (logs.isNotEmpty()) {
                    Text("Historial SMS", style = MaterialTheme.typography.labelMedium)
                    LazyColumn(modifier = Modifier.height(140.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        items(logs.take(20)) { log ->
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(if (log.direction == "sent") "→" else "←",
                                    color = if (log.direction == "sent") MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.tertiary,
                                    fontWeight = FontWeight.Bold)
                                Column {
                                    Text(log.message.take(60), style = MaterialTheme.typography.bodySmall)
                                    Text(sdf.format(Date(log.timestamp)),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrackerFormDialog(
    pets: List<Pet>,
    onDismiss: () -> Unit,
    onSave: (Tracker) -> Unit
) {
    var petId by remember { mutableStateOf(pets.firstOrNull()?.id ?: "") }
    var phone by remember { mutableStateOf("") }
    var chipPassword by remember { mutableStateOf("123456") }
    var name by remember { mutableStateOf("GF-07") }
    var petExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Agregar Tracker GF-07") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it },
                    label = { Text("Nombre del tracker") }, modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp), singleLine = true)

                OutlinedTextField(
                    value = phone, onValueChange = { phone = it },
                    label = { Text("Número SIM del chip *") },
                    modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp),
                    singleLine = true, leadingIcon = { Icon(Icons.Default.SimCard, null) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    supportingText = { Text("El número de teléfono de la SIM dentro del GF-07") }
                )

                OutlinedTextField(value = chipPassword, onValueChange = { chipPassword = it },
                    label = { Text("Contraseña del chip") }, modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp), singleLine = true,
                    supportingText = { Text("Por defecto: 123456") })

                ExposedDropdownMenuBox(expanded = petExpanded, onExpandedChange = { petExpanded = it }) {
                    OutlinedTextField(
                        value = pets.find { it.id == petId }?.name ?: "Seleccionar mascota",
                        onValueChange = {}, readOnly = true, label = { Text("Mascota asociada *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(petExpanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor(), shape = RoundedCornerShape(12.dp)
                    )
                    ExposedDropdownMenu(expanded = petExpanded, onDismissRequest = { petExpanded = false }) {
                        pets.forEach { pet ->
                            DropdownMenuItem(text = { Text(pet.name) },
                                onClick = { petId = pet.id; petExpanded = false })
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(Tracker(petId = petId, phoneNumber = phone.trim(),
                    chipPassword = chipPassword, name = name)) },
                enabled = phone.isNotBlank() && petId.isNotBlank(),
                shape = RoundedCornerShape(12.dp)
            ) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
