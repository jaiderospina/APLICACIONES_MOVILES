package com.example.pet_ultima.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "geofence_alerts")
data class GeofenceAlert(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val petId: String,
    val geofenceId: String,
    val alertType: String, // exit, enter
    val isRead: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
