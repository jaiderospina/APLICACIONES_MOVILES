package com.example.pet_ultima.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.pet_ultima.data.db.Pet
import java.text.SimpleDateFormat
import java.util.*

fun speciesEmoji(species: String): String = when (species) {
    "dog" -> "🐕"
    "cat" -> "🐈"
    "bird" -> "🐦"
    "rabbit" -> "🐇"
    else -> "🐾"
}

fun statusColor(status: String, colors: ColorScheme): androidx.compose.ui.graphics.Color = when (status) {
    "lost" -> colors.error
    "found" -> colors.tertiary
    "inactive" -> colors.outline
    else -> colors.primary
}

fun statusLabel(status: String): String = when (status) {
    "lost" -> "Perdido"
    "found" -> "Encontrado"
    "inactive" -> "Inactivo"
    else -> "Activo"
}

@Composable
fun PetCard(pet: Pet, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Photo or emoji
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (pet.photoUri.isNotBlank()) {
                    AsyncImage(
                        model = pet.photoUri,
                        contentDescription = pet.name,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(speciesEmoji(pet.species), fontSize = 28.sp)
                        }
                    }
                }
            }

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(pet.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = statusColor(pet.status, MaterialTheme.colorScheme).copy(alpha = 0.12f)
                    ) {
                        Text(
                            statusLabel(pet.status),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                            color = statusColor(pet.status, MaterialTheme.colorScheme),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
                Text(
                    pet.species.replaceFirstChar { it.uppercase() } + if (pet.breed.isNotBlank()) " · ${pet.breed}" else "",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (pet.lastKnownLat != null) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Icon(
                            Icons.Default.LocationOn,
                            contentDescription = null,
                            modifier = Modifier.size(12.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                        val time = pet.lastLocationUpdate?.let {
                            SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date(it))
                        } ?: ""
                        Text(time, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }
}
