package com.example.pet_ultima.sms

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import com.example.pet_ultima.data.db.AppDatabase
import com.example.pet_ultima.data.db.Gf07Message
import com.example.pet_ultima.notifications.NotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SmsReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        messages.forEach { sms ->
            val body = sms.messageBody ?: return@forEach
            val sender = sms.originatingAddress ?: ""

            // Parse GF-07 location response — typical format:
            // "lat:4.609700,lon:-74.081700,speed:0.00"
            // OR a Google Maps link: "http://maps.google.com/?q=4.609700,-74.081700"
            val (lat, lng) = parseLocation(body)

            CoroutineScope(Dispatchers.IO).launch {
                val db = AppDatabase.getDatabase(context)
                // Find user whose gf07 number matches sender
                val allUsers = db.userDao().let {
                    var list = emptyList<com.example.pet_ultima.data.db.User>()
                    // We read synchronously here since we're already on IO
                    try {
                        val cursor = db.query(
                            androidx.sqlite.db.SimpleSQLiteQuery("SELECT * FROM users WHERE gf07PhoneNumber = ?", arrayOf(sender))
                        )
                        // fallback: just log for any user
                    } catch (_: Exception) {}
                    list
                }

                // Log message for all users (simplified — in production match by phone)
                db.gf07Dao().insertMessage(
                    Gf07Message(
                        userId = "gf07_incoming", // broadcast receiver doesn't know active user
                        direction = "received",
                        body = body,
                        parsedLat = lat,
                        parsedLng = lng
                    )
                )

                if (lat != null) {
                    NotificationHelper.sendGf07Notification(context, "Ubicación: $lat, $lng\n$body")
                }
            }
        }
    }

    companion object {
        fun parseLocation(body: String): Pair<Double?, Double?> {
            // Try Google Maps link format
            val mapsRegex = Regex("""[?&]q=(-?\d+\.?\d*),(-?\d+\.?\d*)""")
            mapsRegex.find(body)?.let {
                return Pair(it.groupValues[1].toDoubleOrNull(), it.groupValues[2].toDoubleOrNull())
            }

            // Try lat:X,lon:Y format
            val latLonRegex = Regex("""lat[:\s]*(-?\d+\.?\d*).*?lon[:\s]*(-?\d+\.?\d*)""", RegexOption.IGNORE_CASE)
            latLonRegex.find(body)?.let {
                return Pair(it.groupValues[1].toDoubleOrNull(), it.groupValues[2].toDoubleOrNull())
            }

            // Try bare coordinates
            val coordRegex = Regex("""(-?\d{1,3}\.\d{4,})[,\s]+(-?\d{1,3}\.\d{4,})""")
            coordRegex.find(body)?.let {
                return Pair(it.groupValues[1].toDoubleOrNull(), it.groupValues[2].toDoubleOrNull())
            }

            return Pair(null, null)
        }
    }
}
