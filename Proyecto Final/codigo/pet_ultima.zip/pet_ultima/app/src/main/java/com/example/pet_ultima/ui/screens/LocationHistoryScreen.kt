package com.example.pet_ultima.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.pet_ultima.viewmodel.PetViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LocationHistoryScreen(vm: PetViewModel, filterPetId: String?, onBack: () -> Unit) {
    val pets by vm.pets.collectAsState()
    var selectedPetId by remember { mutableStateOf(filterPetId ?: pets.firstOrNull()?.id ?: "") }
    var petExpanded by remember { mutableStateOf(false) }

    val history by vm.getHistoryForPet(selectedPetId).collectAsState(initial = emptyList())
    val sdf = SimpleDateFormat("d MMM yyyy, HH:mm:ss", Locale("es"))

    LaunchedEffect(pets) {
        if (selectedPetId.isBlank() && pets.isNotEmpty()) {
            selectedPetId = pets.first().id
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Historial de Ubicación") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Volver") } }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
            Spacer(Modifier.height(8.dp))
            // Pet selector
            if (pets.isNotEmpty()) {
                ExposedDropdownMenuBox(expanded = petExpanded, onExpandedChange = { petExpanded = it }) {
                    OutlinedTextField(
                        value = pets.find { it.id == selectedPetId }?.name ?: "Seleccionar mascota",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Mascota") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(petExpanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor(),
                        shape = RoundedCornerShape(14.dp)
                    )
                    ExposedDropdownMenu(expanded = petExpanded, onDismissRequest = { petExpanded = false }) {
                        pets.forEach { pet ->
                            DropdownMenuItem(text = { Text(pet.name) }, onClick = { selectedPetId = pet.id; petExpanded = false })
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
            }

            if (selectedPetId.isBlank() || pets.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No hay mascotas registradas", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else if (history.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.LocationOff, null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(8.dp))
                        Text("Sin historial de ubicación", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(12.dp))
                        val pet = pets.find { it.id == selectedPetId }
                        if (pet != null) {
                            Button(
                                onClick = { vm.addLocationPoint(selectedPetId, 4.6097 + Math.random() * 0.01, -74.0817 + Math.random() * 0.01) },
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Icon(Icons.Default.AddLocation, null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Simular ubicación")
                            }
                        }
                    }
                }
            } else {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("${history.size} registros", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    TextButton(onClick = { vm.addLocationPoint(selectedPetId, 4.6097 + Math.random() * 0.01, -74.0817 + Math.random() * 0.01) }) {
                        Icon(Icons.Default.AddLocation, null, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Simular")
                    }
                }
                Spacer(Modifier.height(8.dp))
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(history, key = { it.id }) { loc ->
                        Card(shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Icon(Icons.Default.LocationOn, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("%.6f, %.6f".format(loc.lat, loc.lng), fontWeight = FontWeight.Medium, style = MaterialTheme.typography.bodyMedium)
                                    Text(sdf.format(Date(loc.recordedAt)), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                    item { Spacer(Modifier.height(16.dp)) }
                }
            }
        }
    }
}
