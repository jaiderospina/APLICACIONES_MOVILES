package com.example.pet_ultima.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "gf07_messages")
data class Gf07Message(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val userId: String,
    val direction: String,   // "sent" | "received"
    val body: String,
    val parsedLat: Double? = null,
    val parsedLng: Double? = null,
    val createdAt: Long = System.currentTimeMillis()
)
