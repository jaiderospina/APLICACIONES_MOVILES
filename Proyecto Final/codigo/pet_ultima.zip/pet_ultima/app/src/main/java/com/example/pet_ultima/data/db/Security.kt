package com.example.pet_ultima.data.db

import java.security.MessageDigest

object Security {
    fun hashPassword(password: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(password.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun verifyPassword(input: String, hash: String): Boolean =
        hashPassword(input) == hash
}
