package com.example.pet_ultima.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "pets")
data class Pet(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val userId: String = "",
    val isShared: Boolean = false,       // kept for quick "share with all" toggle
    val name: String,
    val species: String = "dog",
    val breed: String = "",
    val age: Float? = null,
    val weight: Float? = null,
    val photoUri: String = "",
    val color: String = "",
    val microchipId: String = "",
    val status: String = "active",
    val chipPhoneNumber: String = "",    // per-pet GF-07 number override
    val chipPassword: String = "123456", // per-pet GF-07 password override
    val lastKnownLat: Double? = null,
    val lastKnownLng: Double? = null,
    val lastLocationUpdate: Long? = null,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
