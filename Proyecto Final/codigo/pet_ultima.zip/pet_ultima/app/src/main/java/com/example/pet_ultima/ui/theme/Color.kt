package com.example.pet_ultima.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650A4)
val PurpleGrey40 = Color(0xFF625B71)
val Pink40 = Color(0xFF7D5260)

// PetTrack brand colors
val PetGreen = Color(0xFF2E7D32)
val PetGreenLight = Color(0xFF66BB6A)
val PetOrange = Color(0xFFE65100)
