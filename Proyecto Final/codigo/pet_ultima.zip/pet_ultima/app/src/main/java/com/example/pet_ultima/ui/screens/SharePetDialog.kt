package com.example.pet_ultima.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.pet_ultima.data.db.Pet
import com.example.pet_ultima.viewmodel.PetViewModel

@Composable
fun SharePetDialog(
    vm: PetViewModel,
    pet: Pet,
    onDismiss: () -> Unit
) {
    val allUsers by vm.users.collectAsState()
    val sharedUserIds by vm.getSharedUserIds(pet.id).collectAsState(initial = emptyList())
    val activeUser by vm.activeUser.collectAsState()

    // Exclude the owner
    val otherUsers = allUsers.filter { it.id != pet.userId && it.id != activeUser?.id }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.Share, null, tint = MaterialTheme.colorScheme.primary)
                Text("Compartir a ${pet.name}")
            }
        },
        text = {
            if (otherUsers.isEmpty()) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Text("👥", fontSize = 36.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "No hay otros perfiles en este dispositivo",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(otherUsers, key = { it.id }) { user ->
                        val isShared = user.id in sharedUserIds
                        val userColor = try { Color(android.graphics.Color.parseColor(user.colorHex)) }
                        catch (e: Exception) { MaterialTheme.colorScheme.primary }

                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = if (isShared) userColor.copy(alpha = 0.12f)
                                    else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { vm.setShareForUser(pet.id, user.id, !isShared) }
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = userColor.copy(alpha = 0.2f),
                                    modifier = Modifier.size(40.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(user.avatarEmoji, fontSize = 20.sp)
                                    }
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(user.name, fontWeight = FontWeight.SemiBold)
                                    Text(
                                        if (isShared) "Con acceso" else "Sin acceso",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (isShared) userColor else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Checkbox(
                                    checked = isShared,
                                    onCheckedChange = { vm.setShareForUser(pet.id, user.id, it) },
                                    colors = CheckboxDefaults.colors(checkedColor = userColor)
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss, shape = RoundedCornerShape(12.dp)) { Text("Listo") }
        }
    )
}
