package com.example.pet_ultima.sms

object Gf07Commands {
    // Request current location (responds with Google Maps link)
    fun requestLocation(password: String = "123456") = "dw"

    // Start continuous tracking (sends location every interval)
    fun startTracking(password: String = "123456") = "$password begin"

    // Stop tracking
    fun stopTracking(password: String = "123456") = "$password stop"

    // Set tracking interval (unit: minutes, e.g. 1 = every minute)
    fun setInterval(minutes: Int, password: String = "123456") = "$password s00$minutes"

    // Arm SOS alert
    fun armSOS(password: String = "123456") = "$password arm"

    // Disarm SOS
    fun disarmSOS(password: String = "123456") = "$password disarm"

    // Change password
    fun changePassword(old: String, new: String) = "${old}password${new}"

    // Reset to factory
    fun reset(password: String = "123456") = "${password}reset"

    // Parse incoming SMS from GF-07
    // Returns Pair<lat, lng> if it contains a Google Maps link, else null
    fun parseLocationFromSms(message: String): Pair<Double, Double>? {
        // GF-07 responds with: http://maps.google.com/maps?q=4.123456,-74.123456
        val regex = Regex("maps\\.google\\.com/maps\\?q=(-?\\d+\\.\\d+),(-?\\d+\\.\\d+)")
        val match = regex.find(message) ?: return null
        return Pair(
            match.groupValues[1].toDoubleOrNull() ?: return null,
            match.groupValues[2].toDoubleOrNull() ?: return null
        )
    }

    fun isFromGf07(message: String): Boolean {
        return message.contains("maps.google.com") ||
               message.contains("Lat:") ||
               message.contains("tracker") ||
               message.contains("begin") ||
               message.contains("stop")
    }
}
