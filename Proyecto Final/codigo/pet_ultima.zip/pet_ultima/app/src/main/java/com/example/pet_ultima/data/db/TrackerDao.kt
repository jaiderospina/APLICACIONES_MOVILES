package com.example.pet_ultima.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TrackerDao {
    @Query("SELECT * FROM trackers ORDER BY createdAt DESC")
    fun getAllTrackers(): Flow<List<Tracker>>

    @Query("SELECT * FROM trackers WHERE petId = :petId")
    fun getTrackersForPet(petId: String): Flow<List<Tracker>>

    @Query("SELECT * FROM trackers WHERE id = :id")
    suspend fun getTrackerById(id: String): Tracker?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTracker(tracker: Tracker)

    @Update
    suspend fun updateTracker(tracker: Tracker)

    @Query("DELETE FROM trackers WHERE id = :id")
    suspend fun deleteTracker(id: String)
}
