package com.example.pet_ultima.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.pet_ultima.data.db.User
import com.example.pet_ultima.util.hashPassword
import com.example.pet_ultima.util.verifyPassword
import com.example.pet_ultima.viewmodel.PetViewModel
import com.example.pet_ultima.viewmodel.avatarColors
import com.example.pet_ultima.viewmodel.avatarEmojis

@Composable
fun LoginScreen(
    vm: PetViewModel,
    onLoginSuccess: (User) -> Unit
) {
    var isRegistering by remember { mutableStateOf(false) }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var displayName by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }
    var errorMsg by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    val users by vm.users.collectAsState()

    // Auto-switch to register if no users exist
    LaunchedEffect(users) {
        if (users.isEmpty()) isRegistering = true
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("🐾", fontSize = 64.sp)
        Spacer(Modifier.height(8.dp))
        Text("PetTrack", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Text(
            if (isRegistering) "Crear cuenta" else "Iniciar sesión",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(Modifier.height(40.dp))

        Card(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {

                if (isRegistering) {
                    OutlinedTextField(
                        value = displayName,
                        onValueChange = { displayName = it },
                        label = { Text("Nombre visible") },
                        leadingIcon = { Icon(Icons.Default.Badge, null) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                }

                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it.lowercase().trim() },
                    label = { Text("Usuario") },
                    leadingIcon = { Icon(Icons.Default.Person, null) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Contraseña") },
                    leadingIcon = { Icon(Icons.Default.Lock, null) },
                    trailingIcon = {
                        IconButton(onClick = { showPassword = !showPassword }) {
                            Icon(if (showPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility, null)
                        }
                    },
                    visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                if (isRegistering) {
                    OutlinedTextField(
                        value = confirmPassword,
                        onValueChange = { confirmPassword = it },
                        label = { Text("Confirmar contraseña") },
                        leadingIcon = { Icon(Icons.Default.LockOpen, null) },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                }

                if (errorMsg.isNotBlank()) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.errorContainer
                    ) {
                        Text(
                            errorMsg,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }

                Button(
                    onClick = {
                        errorMsg = ""
                        isLoading = true
                        if (isRegistering) {
                            when {
                                displayName.isBlank() -> errorMsg = "Ingresa un nombre visible"
                                username.length < 3 -> errorMsg = "El usuario debe tener al menos 3 caracteres"
                                password.length < 4 -> errorMsg = "La contraseña debe tener al menos 4 caracteres"
                                password != confirmPassword -> errorMsg = "Las contraseñas no coinciden"
                                users.any { it.username == username } -> errorMsg = "El usuario '$username' ya existe"
                                else -> {
                                    val newUser = User(
                                        name = displayName.trim(),
                                        username = username,
                                        passwordHash = hashPassword(password),
                                        avatarEmoji = avatarEmojis.random(),
                                        colorHex = avatarColors.random()
                                    )
                                    vm.saveUser(newUser)
                                    onLoginSuccess(newUser)
                                }
                            }
                        } else {
                            val found = users.find { it.username == username }
                            when {
                                found == null -> errorMsg = "Usuario no encontrado"
                                !verifyPassword(password, found.passwordHash) -> errorMsg = "Contraseña incorrecta"
                                else -> onLoginSuccess(found)
                            }
                        }
                        isLoading = false
                    },
                    enabled = username.isNotBlank() && password.isNotBlank() && !isLoading,
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    if (isLoading) CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    else Text(if (isRegistering) "Crear cuenta" else "Entrar", fontWeight = FontWeight.SemiBold)
                }
            }
        }

        Spacer(Modifier.height(20.dp))

        if (users.isNotEmpty()) {
            TextButton(onClick = {
                isRegistering = !isRegistering
                errorMsg = ""
                password = ""
                confirmPassword = ""
            }) {
                Text(if (isRegistering) "¿Ya tienes cuenta? Inicia sesión" else "¿No tienes cuenta? Regístrate")
            }
        }
    }
}
