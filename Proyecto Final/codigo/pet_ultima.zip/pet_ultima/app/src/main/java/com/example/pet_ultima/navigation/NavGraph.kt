package com.example.pet_ultima.navigation

sealed class Screen(val route: String) {
    object Login : Screen("login")
    object UserSelect : Screen("user_select")
    object ManageUsers : Screen("manage_users")
    object Dashboard : Screen("dashboard")
    object PetList : Screen("pets")
    object PetDetail : Screen("pets/{petId}") {
        fun createRoute(petId: String) = "pets/$petId"
    }
    object PetForm : Screen("pets/form?petId={petId}") {
        fun createRoute(petId: String? = null) = if (petId != null) "pets/form?petId=$petId" else "pets/form"
    }
    object Geofences : Screen("geofences")
    object GeofenceForm : Screen("geofences/form?geofenceId={geofenceId}&petId={petId}") {
        fun createRoute(geofenceId: String? = null, petId: String? = null): String {
            val base = "geofences/form"
            val params = buildList {
                if (geofenceId != null) add("geofenceId=$geofenceId")
                if (petId != null) add("petId=$petId")
            }
            return if (params.isEmpty()) base else "$base?${params.joinToString("&")}"
        }
    }
    object GeofenceDetail : Screen("geofences/{geofenceId}") {
        fun createRoute(id: String) = "geofences/$id"
    }
    object LocationHistory : Screen("history?petId={petId}") {
        fun createRoute(petId: String? = null) = if (petId != null) "history?petId=$petId" else "history"
    }
    object Alerts : Screen("alerts")
    object Profile : Screen("profile")
    object ChipControl : Screen("chip_control")
}
