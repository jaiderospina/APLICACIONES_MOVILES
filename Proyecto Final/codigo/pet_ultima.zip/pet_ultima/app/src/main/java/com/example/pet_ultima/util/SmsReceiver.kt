package com.example.pet_ultima.util

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import com.example.pet_ultima.data.db.AppDatabase
import com.example.pet_ultima.data.db.LocationHistory
import com.example.pet_ultima.data.db.SmsLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        val db = AppDatabase.getDatabase(context)

        messages.forEach { msg ->
            val body = msg.messageBody ?: return@forEach
            val from = msg.originatingAddress ?: ""
            val parsed = Gf07Commands.parseLocation(body)

            CoroutineScope(Dispatchers.IO).launch {
                val log = SmsLog(
                    direction = "received",
                    message = "De $from: $body",
                    parsedLat = parsed?.first,
                    parsedLng = parsed?.second
                )
                db.smsLogDao().insertLog(log)

                if (parsed != null) {
                    val allPets = db.petDao().getAllPets().first()
                    val fromDigits = from.filter { it.isDigit() }.takeLast(7)
                    val pet = allPets.find { p ->
                        p.chipPhoneNumber.isNotBlank() &&
                            p.chipPhoneNumber.filter { it.isDigit() }.takeLast(7) == fromDigits
                    }
                    if (pet != null) {
                        db.locationHistoryDao().insertLocation(
                            LocationHistory(petId = pet.id, lat = parsed.first, lng = parsed.second)
                        )
                        db.petDao().updatePet(
                            pet.copy(
                                lastKnownLat = parsed.first,
                                lastKnownLng = parsed.second,
                                lastLocationUpdate = System.currentTimeMillis()
                            )
                        )
                    }
                }
            }
        }
    }
}
