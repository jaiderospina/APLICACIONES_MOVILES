package com.example.pet_ultima.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface PetShareDao {
    @Query("SELECT sharedWithUserId FROM pet_shares WHERE petId = :petId")
    fun getSharedUserIds(petId: String): Flow<List<String>>

    @Query("SELECT sharedWithUserId FROM pet_shares WHERE petId = :petId")
    suspend fun getSharedUserIdsOnce(petId: String): List<String>

    @Query("SELECT * FROM pet_shares WHERE petId = :petId")
    fun getSharesForPet(petId: String): Flow<List<PetShare>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShare(share: PetShare)

    @Query("DELETE FROM pet_shares WHERE petId = :petId AND sharedWithUserId = :userId")
    suspend fun removeShare(petId: String, userId: String)

    @Query("DELETE FROM pet_shares WHERE petId = :petId")
    suspend fun removeAllSharesForPet(petId: String)

    @Query("SELECT EXISTS(SELECT 1 FROM pet_shares WHERE petId = :petId AND sharedWithUserId = :userId)")
    suspend fun isSharedWith(petId: String, userId: String): Boolean
}
