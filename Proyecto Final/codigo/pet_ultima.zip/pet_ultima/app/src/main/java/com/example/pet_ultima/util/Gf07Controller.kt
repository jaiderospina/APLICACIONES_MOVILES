package com.example.pet_ultima.util

import android.content.Context
import android.telephony.SmsManager
import android.os.Build

/**
 * GF-07 GPS Tracker SMS command controller.
 *
 * The GF-07 chip has a SIM card. You send SMS commands to its number
 * and it replies with location data or confirmations.
 *
 * Default password: 123456
 * Location reply format: Google Maps link or lat/lng coordinates
 */
object Gf07Controller {

    // --- Command builders ---

    /** Request current location (no password needed) */
    fun cmdLocation() = "dw"

    /** Request location with coordinates in reply */
    fun cmdLocationCoords(password: String) = "${password} D"

    /** Start continuous tracking (sends location every ~10 min) */
    fun cmdStartTracker(password: String) = "${password} tracker"

    /** Stop continuous tracking */
    fun cmdStopTracker(password: String) = "${password} stop"

    /** Set tracking interval in minutes (1-99) */
    fun cmdSetInterval(password: String, minutes: Int) = "${password} norinco${minutes.coerceIn(1, 99)}"

    /** Change password */
    fun cmdChangePassword(oldPassword: String, newPassword: String) = "${oldPassword} password${newPassword}"

    /** Set admin phone number (who can receive location) */
    fun cmdSetAdmin(password: String, phoneNumber: String) = "${password} admin${phoneNumber}"

    /** Reset to factory defaults */
    fun cmdReset(password: String) = "${password} reset"

    /** SOS — send location to admin */
    fun cmdSOS() = "help me"

    /** Enable/disable power-saving mode */
    fun cmdLowBattery(password: String, enabled: Boolean) =
        if (enabled) "${password} low battery" else "${password} move"

    // --- SMS sending ---

    /**
     * Sends an SMS command to the GF-07.
     * Requires SEND_SMS permission granted at runtime.
     * Returns true if sent successfully, false otherwise.
     */
    fun sendCommand(context: Context, chipNumber: String, command: String): Result<Unit> {
        return try {
            if (chipNumber.isBlank()) return Result.failure(Exception("Número del chip no configurado"))
            val smsManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                context.getSystemService(SmsManager::class.java)
            } else {
                @Suppress("DEPRECATION")
                SmsManager.getDefault()
            }
            smsManager.sendTextMessage(chipNumber, null, command, null, null)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Parse a location reply from the GF-07.
     * Typical replies:
     *   - "http://maps.google.com/maps?q=4.123,-74.456"
     *   - "Lat:4.123456 Long:-74.456789 Speed:0.00 ..."
     */
    fun parseLocationReply(smsBody: String): Gf07Location? {
        // Google Maps link format
        val mapsRegex = Regex("""maps\?q=([-\d.]+),([-\d.]+)""")
        mapsRegex.find(smsBody)?.let {
            val lat = it.groupValues[1].toDoubleOrNull()
            val lng = it.groupValues[2].toDoubleOrNull()
            if (lat != null && lng != null) return Gf07Location(lat, lng, smsBody)
        }

        // Lat/Long text format
        val coordRegex = Regex("""[Ll]at[:\s]*([-\d.]+).*?[Ll]on[g]?[:\s]*([-\d.]+)""", RegexOption.DOT_MATCHES_ALL)
        coordRegex.find(smsBody)?.let {
            val lat = it.groupValues[1].toDoubleOrNull()
            val lng = it.groupValues[2].toDoubleOrNull()
            if (lat != null && lng != null) return Gf07Location(lat, lng, smsBody)
        }

        return null
    }
}

data class Gf07Location(
    val lat: Double,
    val lng: Double,
    val rawReply: String
)
