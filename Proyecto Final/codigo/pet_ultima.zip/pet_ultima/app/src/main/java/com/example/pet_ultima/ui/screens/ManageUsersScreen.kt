package com.example.pet_ultima.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.pet_ultima.data.db.User
import com.example.pet_ultima.util.SecurityUtil
import com.example.pet_ultima.viewmodel.PetViewModel
import com.example.pet_ultima.viewmodel.avatarColors
import com.example.pet_ultima.viewmodel.avatarEmojis

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ManageUsersScreen(vm: PetViewModel, onBack: () -> Unit) {
    val users by vm.users.collectAsState()
    var showForm by remember { mutableStateOf(false) }
    var editingUser by remember { mutableStateOf<User?>(null) }
    var deleteTarget by remember { mutableStateOf<User?>(null) }

    if (deleteTarget != null) {
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("¿Eliminar perfil?") },
            text = { Text("Se eliminará el perfil \"${deleteTarget!!.name}\".") },
            confirmButton = {
                TextButton(
                    onClick = { vm.deleteUser(deleteTarget!!.id); deleteTarget = null },
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) { Text("Eliminar") }
            },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Cancelar") } }
        )
    }

    if (showForm) {
        UserFormDialog(
            existing = editingUser,
            onDismiss = { showForm = false; editingUser = null },
            onSave = { user ->
                if (editingUser != null) vm.updateUser(user) else vm.saveUser(user)
                showForm = false; editingUser = null
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Gestionar Perfiles") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Volver") } },
                actions = {
                    IconButton(onClick = { editingUser = null; showForm = true }) {
                        Icon(Icons.Default.Add, "Nuevo perfil")
                    }
                }
            )
        }
    ) { padding ->
        if (users.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("👤", fontSize = 48.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("No hay perfiles", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { showForm = true }, shape = RoundedCornerShape(14.dp)) {
                        Icon(Icons.Default.Add, null, Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Crear perfil")
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(users, key = { it.id }) { user ->
                    val color = try { Color(android.graphics.Color.parseColor(user.colorHex)) }
                    catch (e: Exception) { MaterialTheme.colorScheme.primary }
                    Card(shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                        Row(modifier = Modifier.fillMaxWidth().padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            Surface(shape = RoundedCornerShape(14.dp), color = color.copy(alpha = 0.18f),
                                modifier = Modifier.size(52.dp)) {
                                Box(contentAlignment = Alignment.Center) { Text(user.avatarEmoji, fontSize = 26.sp) }
                            }
                            Column(Modifier.weight(1f)) {
                                Text(user.name, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyLarge)
                                Text(
                                    if (user.passwordHash.isBlank()) "Sin contraseña" else "Con contraseña",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (user.passwordHash.isBlank()) MaterialTheme.colorScheme.error
                                            else MaterialTheme.colorScheme.primary
                                )
                            }
                            IconButton(onClick = { editingUser = user; showForm = true }) {
                                Icon(Icons.Default.Edit, "Editar", tint = MaterialTheme.colorScheme.primary)
                            }
                            IconButton(onClick = { deleteTarget = user }) {
                                Icon(Icons.Default.Delete, "Eliminar", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
                item { Spacer(Modifier.height(16.dp)) }
            }
        }
    }
}

@Composable
fun UserFormDialog(existing: User?, onDismiss: () -> Unit, onSave: (User) -> Unit) {
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var showPw by remember { mutableStateOf(false) }
    var selectedEmoji by remember { mutableStateOf(existing?.avatarEmoji ?: "🐾") }
    var selectedColor by remember { mutableStateOf(existing?.colorHex ?: "#6650A4") }
    var nameError by remember { mutableStateOf("") }
    var pwError by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing != null) "Editar perfil" else "Nuevo perfil") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = name, onValueChange = { name = it; nameError = "" },
                    label = { Text("Nombre *") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp), singleLine = true,
                    isError = nameError.isNotBlank(),
                    supportingText = if (nameError.isNotBlank()) {{ Text(nameError) }} else null
                )

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it; pwError = "" },
                    label = { Text(if (existing != null) "Nueva contraseña (dejar vacío para no cambiar)" else "Contraseña") },
                    trailingIcon = {
                        IconButton(onClick = { showPw = !showPw }) {
                            Icon(if (showPw) Icons.Default.VisibilityOff else Icons.Default.Visibility, null)
                        }
                    },
                    visualTransformation = if (showPw) VisualTransformation.None else PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp), singleLine = true,
                    isError = pwError.isNotBlank()
                )

                if (password.isNotBlank()) {
                    OutlinedTextField(
                        value = confirmPassword, onValueChange = { confirmPassword = it; pwError = "" },
                        label = { Text("Confirmar contraseña") },
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp), singleLine = true,
                        isError = pwError.isNotBlank(),
                        supportingText = if (pwError.isNotBlank()) {{ Text(pwError) }} else null
                    )
                }

                Text("Avatar", style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(avatarEmojis) { emoji ->
                        Surface(shape = RoundedCornerShape(10.dp),
                            color = if (emoji == selectedEmoji) MaterialTheme.colorScheme.primaryContainer
                                    else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.size(44.dp).clickable { selectedEmoji = emoji }) {
                            Box(contentAlignment = Alignment.Center) { Text(emoji, fontSize = 22.sp) }
                        }
                    }
                }

                Text("Color", style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(avatarColors) { hex ->
                        val c = try { Color(android.graphics.Color.parseColor(hex)) } catch (e: Exception) { Color.Gray }
                        Surface(
                            shape = RoundedCornerShape(10.dp), color = c,
                            modifier = Modifier.size(36.dp).clickable { selectedColor = hex },
                            border = if (hex == selectedColor)
                                androidx.compose.foundation.BorderStroke(3.dp, MaterialTheme.colorScheme.onSurface)
                            else null
                        ) {}
                    }
                }

                // Preview
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    val pc = try { Color(android.graphics.Color.parseColor(selectedColor)) } catch (e: Exception) { Color.Gray }
                    Surface(shape = RoundedCornerShape(12.dp), color = pc.copy(alpha = 0.18f), modifier = Modifier.size(48.dp)) {
                        Box(contentAlignment = Alignment.Center) { Text(selectedEmoji, fontSize = 24.sp) }
                    }
                    Text(name.ifBlank { "Vista previa" }, fontWeight = FontWeight.SemiBold)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isBlank()) { nameError = "Nombre requerido"; return@Button }
                    if (password.isNotBlank()) {
                        if (!SecurityUtil.isValidPassword(password)) { pwError = "Mínimo 4 caracteres"; return@Button }
                        if (password != confirmPassword) { pwError = "Las contraseñas no coinciden"; return@Button }
                    }
                    val hash = when {
                        password.isNotBlank() -> SecurityUtil.hashPassword(password)
                        existing != null -> existing.passwordHash
                        else -> ""
                    }
                    onSave(User(
                        id = existing?.id ?: java.util.UUID.randomUUID().toString(),
                        name = name.trim(),
                        passwordHash = hash,
                        avatarEmoji = selectedEmoji,
                        colorHex = selectedColor,
                        createdAt = existing?.createdAt ?: System.currentTimeMillis()
                    ))
                },
                shape = RoundedCornerShape(12.dp)
            ) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
