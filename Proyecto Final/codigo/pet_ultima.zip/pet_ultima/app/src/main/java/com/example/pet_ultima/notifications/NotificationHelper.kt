package com.example.pet_ultima.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import com.example.pet_ultima.MainActivity
import com.example.pet_ultima.R

object NotificationHelper {
    const val CHANNEL_GEOFENCE_ALARM = "geofence_alarm"
    const val CHANNEL_GF07_SMS = "gf07_sms"

    fun createChannels(context: Context) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        // Geofence alarm channel — max importance
        val alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

        val alarmAttrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        val geofenceChannel = NotificationChannel(
            CHANNEL_GEOFENCE_ALARM,
            "Alertas de Geocerca",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Notificaciones de alarma cuando la mascota sale de una geocerca"
            setSound(alarmSound, alarmAttrs)
            enableVibration(true)
            vibrationPattern = longArrayOf(0, 500, 200, 500, 200, 500)
            enableLights(true)
            lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
        }

        // GF07 SMS channel
        val smsChannel = NotificationChannel(
            CHANNEL_GF07_SMS,
            "Mensajes GF-07",
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = "Respuestas SMS del chip rastreador GF-07"
        }

        nm.createNotificationChannel(geofenceChannel)
        nm.createNotificationChannel(smsChannel)
    }

    fun sendGeofenceAlarm(context: Context, petName: String, geofenceName: String, alertType: String) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        // Vibrate
        val vibPattern = longArrayOf(0, 600, 200, 600, 200, 600)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vm.defaultVibrator.vibrate(VibrationEffect.createWaveform(vibPattern, -1))
        } else {
            @Suppress("DEPRECATION")
            val v = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            @Suppress("DEPRECATION")
            v.vibrate(vibPattern, -1)
        }

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("nav_to", "alerts")
        }
        val pi = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_IMMUTABLE)

        val typeLabel = if (alertType == "exit") "salió de" else "entró a"
        val alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

        val notification = NotificationCompat.Builder(context, CHANNEL_GEOFENCE_ALARM)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("⚠️ ALERTA — $petName")
            .setContentText("$petName $typeLabel la geocerca \"$geofenceName\"")
            .setStyle(NotificationCompat.BigTextStyle()
                .bigText("Tu mascota $petName $typeLabel la zona de seguridad \"$geofenceName\". Verifica su ubicación de inmediato."))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setSound(alarmSound)
            .setVibrate(vibPattern)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .setFullScreenIntent(pi, true)
            .build()

        nm.notify(System.currentTimeMillis().toInt(), notification)
    }

    fun sendGf07Notification(context: Context, body: String) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notification = NotificationCompat.Builder(context, CHANNEL_GF07_SMS)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("📍 GF-07 — Ubicación recibida")
            .setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()
        nm.notify(System.currentTimeMillis().toInt(), notification)
    }
}
