package com.example.pet_ultima.sms

import android.content.Context
import android.telephony.SmsManager
import android.widget.Toast

object GF07SmsManager {

    // All GF-07 commands
    fun requestLocation(context: Context, phone: String, password: String = "123456") {
        sendSms(context, phone, "dw")
    }

    fun startTracking(context: Context, phone: String, password: String = "123456") {
        sendSms(context, phone, "$password begin")
    }

    fun stopTracking(context: Context, phone: String, password: String = "123456") {
        sendSms(context, phone, "$password stop")
    }

    fun setTrackerMode(context: Context, phone: String, password: String = "123456") {
        sendSms(context, phone, "$password tracker")
    }

    fun setTimedReport(context: Context, phone: String, intervalMinutes: Int, password: String = "123456") {
        // e.g. "123456 t030s005n001" = every 30 sec, 5 times, every 1 min
        val interval = intervalMinutes.toString().padStart(3, '0')
        sendSms(context, phone, "$password t${interval}s010n001")
    }

    fun reset(context: Context, phone: String, password: String = "123456") {
        sendSms(context, phone, "reset")
    }

    fun checkStatus(context: Context, phone: String) {
        sendSms(context, phone, "CXZT")
    }

    fun callPhone(context: Context, phone: String, monitorPhone: String, password: String = "123456") {
        sendSms(context, phone, "$password monitor$monitorPhone")
    }

    private fun sendSms(context: Context, phone: String, message: String) {
        try {
            val manager = context.getSystemService(SmsManager::class.java)
                ?: SmsManager.getDefault()
            manager.sendTextMessage(phone, null, message, null, null)
        } catch (e: Exception) {
            Toast.makeText(context, "Error al enviar SMS: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
