package com.example.pet_ultima.util

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.pet_ultima.MainActivity
import com.example.pet_ultima.R

object NotificationUtil {

    const val CHANNEL_GEOFENCE_ALARM = "geofence_alarm"
    const val CHANNEL_SMS_RESPONSE   = "sms_response"

    fun createChannels(context: Context) {
        val alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

        val audioAttr = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        // High-priority alarm channel for geofence exits
        val alarmChannel = NotificationChannel(
            CHANNEL_GEOFENCE_ALARM,
            "Alertas de Geocerca",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Notificaciones urgentes cuando tu mascota sale de una zona segura"
            setSound(alarmSound, audioAttr)
            enableVibration(true)
            vibrationPattern = longArrayOf(0, 500, 200, 500, 200, 500)
            enableLights(true)
            lightColor = android.graphics.Color.RED
        }

        // Normal channel for SMS responses
        val smsChannel = NotificationChannel(
            CHANNEL_SMS_RESPONSE,
            "Respuestas GPS",
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = "Respuestas del chip GF-07"
        }

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(alarmChannel)
        nm.createNotificationChannel(smsChannel)
    }

    fun sendGeofenceAlarm(
        context: Context,
        petName: String,
        geofenceName: String,
        alertType: String,
        notifId: Int
    ) {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("openAlerts", true)
        }
        val pi = PendingIntent.getActivity(
            context, notifId, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val emoji = if (alertType == "exit") "🚨" else "✅"
        val action = if (alertType == "exit") "SALIÓ DE" else "ENTRÓ A"
        val alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)

        val notif = NotificationCompat.Builder(context, CHANNEL_GEOFENCE_ALARM)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("$emoji Alerta de mascota")
            .setContentText("$petName $action la zona \"$geofenceName\"")
            .setStyle(NotificationCompat.BigTextStyle()
                .bigText("$petName $action la zona segura \"$geofenceName\". Revisa su ubicación ahora."))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setSound(alarmSound)
            .setVibrate(longArrayOf(0, 500, 200, 500, 200, 500))
            .setAutoCancel(true)
            .setContentIntent(pi)
            .setColor(android.graphics.Color.RED)
            .build()

        // Also trigger vibration directly
        vibrateDevice(context)

        try {
            NotificationManagerCompat.from(context).notify(notifId, notif)
        } catch (e: SecurityException) {
            // POST_NOTIFICATIONS permission not granted
        }
    }

    fun sendSmsResponseNotif(context: Context, petName: String, message: String) {
        val notif = NotificationCompat.Builder(context, CHANNEL_SMS_RESPONSE)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("📍 Respuesta GPS – $petName")
            .setContentText(message)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        try {
            NotificationManagerCompat.from(context)
                .notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), notif)
        } catch (e: SecurityException) { /* ignore */ }
    }

    private fun vibrateDevice(context: Context) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vm.defaultVibrator.vibrate(
                    VibrationEffect.createWaveform(longArrayOf(0, 500, 200, 500, 200, 500), -1)
                )
            } else {
                @Suppress("DEPRECATION")
                val v = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                @Suppress("DEPRECATION")
                v.vibrate(longArrayOf(0, 500, 200, 500, 200, 500), -1)
            }
        } catch (e: Exception) { /* ignore */ }
    }
}
