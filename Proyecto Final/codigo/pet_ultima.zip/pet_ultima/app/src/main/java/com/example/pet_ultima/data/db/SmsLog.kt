package com.example.pet_ultima.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "sms_logs")
data class SmsLog(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val petId: String = "",
    val direction: String,   // "sent" | "received"
    val message: String,
    val parsedLat: Double? = null,
    val parsedLng: Double? = null,
    val timestamp: Long = System.currentTimeMillis()
)
