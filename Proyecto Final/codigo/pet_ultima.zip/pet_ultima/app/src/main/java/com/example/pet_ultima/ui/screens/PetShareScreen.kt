package com.example.pet_ultima.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.pet_ultima.data.db.Pet
import com.example.pet_ultima.viewmodel.PetViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PetShareScreen(vm: PetViewModel, petId: String, onBack: () -> Unit) {
    var pet by remember { mutableStateOf<Pet?>(null) }
    val users by vm.users.collectAsState()
    val activeUser by vm.activeUser.collectAsState()
    val shares by vm.getSharesForPet(petId).collectAsState(initial = emptyList())
    val sharedUserIds = shares.map { it.sharedWithUserId }.toSet()

    // Other users (not the owner)
    val otherUsers = users.filter { it.id != activeUser?.id && it.id != pet?.userId }

    LaunchedEffect(petId) { pet = vm.getPetById(petId) }
    val pets by vm.pets.collectAsState()
    LaunchedEffect(pets) { pet = vm.getPetById(petId) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Compartir ${pet?.name ?: "mascota"}") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Volver") } }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {

            // Header card
            Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(pet?.let {
                        when (it.species) { "dog" -> "🐕"; "cat" -> "🐈"; "bird" -> "🐦"; "rabbit" -> "🐇"; else -> "🐾" }
                    } ?: "🐾", fontSize = 32.sp)
                    Column {
                        Text("Compartir acceso", fontWeight = FontWeight.Bold)
                        Text("Elige quién puede ver a ${pet?.name ?: "esta mascota"}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            if (otherUsers.isEmpty()) {
                Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.GroupOff, null, modifier = Modifier.size(40.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(8.dp))
                        Text("No hay otros perfiles en este dispositivo", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            } else {
                Text("Perfiles en este dispositivo", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(otherUsers, key = { it.id }) { user ->
                        val isShared = user.id in sharedUserIds
                        val userColor = try { Color(android.graphics.Color.parseColor(user.colorHex)) }
                        catch (e: Exception) { MaterialTheme.colorScheme.primary }

                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isShared) userColor.copy(alpha = 0.1f)
                                else MaterialTheme.colorScheme.surfaceVariant
                            ),
                            border = if (isShared) androidx.compose.foundation.BorderStroke(1.5.dp, userColor.copy(alpha = 0.4f)) else null
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                Surface(shape = RoundedCornerShape(12.dp), color = userColor.copy(alpha = 0.2f), modifier = Modifier.size(48.dp)) {
                                    Box(contentAlignment = Alignment.Center) { Text(user.avatarEmoji, fontSize = 24.sp) }
                                }
                                Column(Modifier.weight(1f)) {
                                    Text(user.name, fontWeight = FontWeight.SemiBold)
                                    Text(
                                        if (isShared) "✅ Tiene acceso" else "Sin acceso",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (isShared) userColor else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Switch(
                                    checked = isShared,
                                    onCheckedChange = { give -> vm.setShareForUser(petId, user.id, give) },
                                    colors = SwitchDefaults.colors(checkedThumbColor = userColor, checkedTrackColor = userColor.copy(alpha = 0.3f))
                                )
                            }
                        }
                    }
                }
            }

            // Remove all shares
            if (sharedUserIds.isNotEmpty()) {
                Spacer(Modifier.height(16.dp))
                OutlinedButton(
                    onClick = { vm.removeAllShares(petId) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) {
                    Icon(Icons.Default.PersonOff, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Quitar todos los accesos")
                }
            }
        }
    }
}
