package com.example.pet_ultima.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.pet_ultima.viewmodel.PetViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(vm: PetViewModel, onChangeUser: () -> Unit, onManageUsers: () -> Unit, onChipControl: () -> Unit = {}) {
    val pets by vm.pets.collectAsState()
    val geofences by vm.geofences.collectAsState()
    val alerts by vm.alerts.collectAsState()
    val activeUser by vm.activeUser.collectAsState()
    val users by vm.users.collectAsState()

    val userColor = activeUser?.let {
        try { Color(android.graphics.Color.parseColor(it.colorHex)) }
        catch (e: Exception) { null }
    } ?: MaterialTheme.colorScheme.primary

    Scaffold(topBar = { TopAppBar(title = { Text("Mi Perfil") }) }) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Active user card
            Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = userColor.copy(alpha = 0.1f))) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = userColor.copy(alpha = 0.2f),
                        modifier = Modifier.size(80.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(activeUser?.avatarEmoji ?: "🐾", fontSize = 40.sp)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Text(
                        activeUser?.name ?: "Sin perfil",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleLarge
                    )
                    Text(
                        "${users.size} perfil${if (users.size != 1) "es" else ""} en este dispositivo",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedButton(
                            onClick = onChangeUser,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.SwitchAccount, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Cambiar perfil")
                        }
                        OutlinedButton(
                            onClick = onManageUsers,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.ManageAccounts, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Gestionar")
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = onChipControl,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.SettingsInputAntenna, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Control de Chip")
                    }
                }
            }

            // Stats for current user
            Card(shape = RoundedCornerShape(16.dp)) {
                Column(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Resumen de ${activeUser?.name ?: "este perfil"}", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleSmall)
                    ProfileStatRow(icon = Icons.Default.Pets, label = "Mascotas visibles", value = pets.size.toString())
                    HorizontalDivider()
                    ProfileStatRow(icon = Icons.Default.Share, label = "Mascotas compartidas", value = pets.count { it.isShared }.toString())
                    HorizontalDivider()
                    ProfileStatRow(icon = Icons.Default.Shield, label = "Geocercas activas", value = geofences.count { it.isActive }.toString())
                    HorizontalDivider()
                    ProfileStatRow(icon = Icons.Default.Notifications, label = "Alertas no leídas", value = alerts.count { !it.isRead }.toString())
                }
            }

            // App info
            Card(shape = RoundedCornerShape(16.dp)) {
                Column(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Acerca de", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleSmall)
                    Text("PetTrack v1.0", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Monitorea la ubicación y seguridad de tus mascotas.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
fun ProfileStatRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, null, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
        }
        Text(value, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
    }
}
