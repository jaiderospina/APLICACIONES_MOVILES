package com.example.pet_ultima.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.pet_ultima.navigation.Screen
import com.example.pet_ultima.ui.components.PetCard
import com.example.pet_ultima.viewmodel.PetViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PetListScreen(vm: PetViewModel, onNavigate: (String) -> Unit) {
    val pets by vm.pets.collectAsState()
    var search by remember { mutableStateOf("") }
    var statusFilter by remember { mutableStateOf("all") }

    val filtered = pets.filter { p ->
        val matchSearch = p.name.contains(search, true) || p.breed.contains(search, true)
        val matchStatus = statusFilter == "all" || p.status == statusFilter
        matchSearch && matchStatus
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Mis Mascotas") }, actions = {
                IconButton(onClick = { onNavigate(Screen.PetForm.createRoute()) }) {
                    Icon(Icons.Default.Add, "Agregar mascota")
                }
            })
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Buscar mascota...") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                shape = RoundedCornerShape(14.dp),
                singleLine = true
            )
            Spacer(Modifier.height(8.dp))
            // Status filter chips
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("all" to "Todos", "active" to "Activos", "lost" to "Perdidos").forEach { (val_, label) ->
                    FilterChip(
                        selected = statusFilter == val_,
                        onClick = { statusFilter = val_ },
                        label = { Text(label) }
                    )
                }
            }
            Spacer(Modifier.height(12.dp))

            if (filtered.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        if (search.isNotBlank()) "Sin resultados" else "No tienes mascotas registradas",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(filtered, key = { it.id }) { pet ->
                        PetCard(pet = pet, onClick = { onNavigate(Screen.PetDetail.createRoute(pet.id)) })
                    }
                    item { Spacer(Modifier.height(16.dp)) }
                }
            }
        }
    }
}
