package com.example.pet_ultima.viewmodel
// avatarEmojis and avatarColors are defined in PetViewModel.kt
