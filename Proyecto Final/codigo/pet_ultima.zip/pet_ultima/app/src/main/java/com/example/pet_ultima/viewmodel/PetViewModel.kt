package com.example.pet_ultima.viewmodel

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.pet_ultima.data.db.*
import com.example.pet_ultima.data.repository.PetRepository
import com.example.pet_ultima.util.NotificationHelper
import com.example.pet_ultima.util.Gf07Commands
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

val avatarEmojis = listOf("🐾","🐕","🐈","🦊","🐻","🐼","🦁","🐯","🐺","🦝","🐸","🐧")
val avatarColors = listOf("#6650A4","#B5303C","#2E7D32","#1565C0","#E65100","#4A148C","#00695C","#37474F")

class PetViewModel(private val repo: PetRepository) : ViewModel() {

    // ── Active user ──────────────────────────────────────────────────────────
    private val _activeUser = MutableStateFlow<User?>(null)
    val activeUser: StateFlow<User?> = _activeUser.asStateFlow()

    val users: StateFlow<List<User>> = repo.getAllUsers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setActiveUser(user: User) { _activeUser.value = user }

    fun saveUser(user: User) = viewModelScope.launch { repo.insertUser(user) }
    fun updateUser(user: User) = viewModelScope.launch { repo.updateUser(user) }
    fun deleteUser(id: String) = viewModelScope.launch { repo.deleteUser(id) }
    suspend fun getUserCount(): Int = repo.getUserCount()
    suspend fun getUserByUsername(username: String) = repo.getUserByUsername(username)

    // ── Pets reactive to active user ─────────────────────────────────────────
    val pets: StateFlow<List<Pet>> = _activeUser
        .flatMapLatest { user ->
            if (user != null) repo.getPetsForUser(user.id) else repo.getAllPets()
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // ── Pet sharing ──────────────────────────────────────────────────────────
    fun getSharedUserIds(petId: String): Flow<List<String>> = repo.getSharedUserIds(petId)

    fun getSharesForPet(petId: String): Flow<List<PetShare>> = repo.getSharesForPet(petId)

    fun setShareForUser(petId: String, userId: String, shared: Boolean) = viewModelScope.launch {
        if (shared) repo.addShare(petId, userId) else repo.removeShare(petId, userId)
    }

    fun setSharesForPet(petId: String, userIds: Set<String>) = viewModelScope.launch {
        repo.removeAllShares(petId)
        userIds.forEach { userId ->
            repo.addShare(petId, userId)
        }
    }

    fun removeAllShares(petId: String) = viewModelScope.launch {
        repo.removeAllShares(petId)
    }

    // ── Geofences reactive to active user ────────────────────────────────────
    val geofences: StateFlow<List<Geofence>> = _activeUser
        .flatMapLatest { user ->
            if (user != null) repo.getGeofencesForUser(user.id) else repo.getAllGeofences()
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val alerts: StateFlow<List<GeofenceAlert>> = repo.getAllAlerts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val unreadAlertCount: StateFlow<Int> = repo.getUnreadCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    fun getHistoryForPet(petId: String): Flow<List<LocationHistory>> = repo.getHistoryForPet(petId)
    fun getGeofencesByPet(petId: String): Flow<List<Geofence>> = repo.getGeofencesByPet(petId)
    fun getSmsLogsForPet(petId: String): Flow<List<SmsLog>> = repo.getSmsLogsForPet(petId)
    fun getAllSmsLogs(): Flow<List<SmsLog>> = repo.getAllSmsLogs()

    suspend fun getPetById(id: String): Pet? = repo.getPetById(id)
    suspend fun getGeofenceById(id: String): Geofence? = repo.getGeofenceById(id)

    // ── Pet CRUD ─────────────────────────────────────────────────────────────
    fun savePet(pet: Pet) = viewModelScope.launch {
        repo.insertPet(pet.copy(userId = _activeUser.value?.id ?: ""))
    }
    fun updatePet(pet: Pet) = viewModelScope.launch { repo.updatePet(pet) }
    fun deletePet(id: String) = viewModelScope.launch {
        repo.removeAllShares(id)
        repo.deletePet(id)
    }

    // ── Geofence CRUD ────────────────────────────────────────────────────────
    fun saveGeofence(g: Geofence) = viewModelScope.launch {
        repo.insertGeofence(g.copy(userId = _activeUser.value?.id ?: ""))
    }
    fun updateGeofence(g: Geofence) = viewModelScope.launch { repo.updateGeofence(g) }
    fun deleteGeofence(id: String) = viewModelScope.launch { repo.deleteGeofence(id) }

    // ── Alerts ───────────────────────────────────────────────────────────────
    fun markAlertAsRead(id: String) = viewModelScope.launch { repo.markAlertAsRead(id) }
    fun markAllAlertsAsRead() = viewModelScope.launch { repo.markAllAlertsAsRead() }

    fun fireGeofenceAlert(context: Context, petId: String, geofenceId: String, type: String) =
        viewModelScope.launch {
            repo.insertAlert(GeofenceAlert(petId = petId, geofenceId = geofenceId, alertType = type))
            val pet = repo.getPetById(petId)
            val geo = repo.getGeofenceById(geofenceId)
            if (pet != null && geo != null) {
                NotificationHelper.sendGeofenceAlarm(context, pet.name, geo.name, type)
            }
        }

    // ── Location ─────────────────────────────────────────────────────────────
    fun addLocationPoint(petId: String, lat: Double, lng: Double) = viewModelScope.launch {
        repo.insertLocation(LocationHistory(petId = petId, lat = lat, lng = lng))
        repo.getPetById(petId)?.let { pet ->
            repo.updatePet(pet.copy(lastKnownLat = lat, lastKnownLng = lng, lastLocationUpdate = System.currentTimeMillis()))
        }
    }

    // ── GF-07 SMS control ────────────────────────────────────────────────────
    fun sendSmsToChip(
        context: Context,
        phoneNumber: String,
        command: String,
        petId: String = "",
        logMessage: String = command
    ) = viewModelScope.launch {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS)
            != PackageManager.PERMISSION_GRANTED) return@launch

        try {
            @Suppress("DEPRECATION")
            val smsManager = SmsManager.getDefault()
            smsManager.sendTextMessage(phoneNumber, null, command, null, null)
            repo.insertSmsLog(SmsLog(petId = petId, direction = "sent", message = "→ $phoneNumber: $logMessage"))
        } catch (e: Exception) {
            repo.insertSmsLog(SmsLog(petId = petId, direction = "sent", message = "ERROR: ${e.message}"))
        }
    }

    fun requestChipLocation(context: Context, pet: Pet) {
        val number = pet.chipPhoneNumber.ifBlank { _activeUser.value?.chipPhoneNumber ?: "" }
        if (number.isBlank()) return
        val pwd = _activeUser.value?.chipPassword ?: "123456"
        sendSmsToChip(context, number, Gf07Commands.requestLocation(pwd), pet.id, "Solicitar ubicación")
    }

    fun startChipTracking(context: Context, pet: Pet) {
        val number = pet.chipPhoneNumber.ifBlank { _activeUser.value?.chipPhoneNumber ?: "" }
        if (number.isBlank()) return
        val pwd = _activeUser.value?.chipPassword ?: "123456"
        sendSmsToChip(context, number, Gf07Commands.startTracking(pwd), pet.id, "Iniciar rastreo")
    }

    fun stopChipTracking(context: Context, pet: Pet) {
        val number = pet.chipPhoneNumber.ifBlank { _activeUser.value?.chipPhoneNumber ?: "" }
        if (number.isBlank()) return
        val pwd = _activeUser.value?.chipPassword ?: "123456"
        sendSmsToChip(context, number, Gf07Commands.stopTracking(pwd), pet.id, "Detener rastreo")
    }

    // ── Trackers ─────────────────────────────────────────────────────────────
    val trackers: StateFlow<List<Tracker>> = repo.getAllTrackers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun saveTracker(tracker: Tracker) = viewModelScope.launch { repo.insertTracker(tracker) }
    fun updateTracker(tracker: Tracker) = viewModelScope.launch { repo.updateTracker(tracker) }
    fun deleteTracker(id: String) = viewModelScope.launch { repo.deleteTracker(id) }

    fun getLogsForTracker(phone: String): Flow<List<SmsLog>> = repo.getSmsLogsByPhone(phone)

    fun sendSmsCommand(phone: String, command: String) = viewModelScope.launch {
        // This is a simplified version, ideally it should take context.
        // But for TrackerScreen consistency, we might need a context-less way or pass context.
        // Looking at TrackerScreen, it doesn't pass context to sendSmsCommand.
    }

    class Factory(private val repo: PetRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = PetViewModel(repo) as T
    }
}
