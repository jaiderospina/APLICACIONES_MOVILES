package com.example.pet_ultima.ui.screens

import android.Manifest
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.pet_ultima.data.db.Geofence
import com.example.pet_ultima.viewmodel.PetViewModel
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberMultiplePermissionsState
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polygon
import kotlin.math.cos

@OptIn(ExperimentalMaterial3Api::class, ExperimentalPermissionsApi::class)
@Composable
fun GeofenceFormScreen(
    vm: PetViewModel,
    geofenceId: String?,
    preselectedPetId: String?,
    onBack: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    var petId by remember { mutableStateOf(preselectedPetId ?: "") }
    var centerLat by remember { mutableStateOf(4.6097) }
    var centerLng by remember { mutableStateOf(-74.0817) }
    var radius by remember { mutableStateOf("100") }
    var isActive by remember { mutableStateOf(true) }
    var alertType by remember { mutableStateOf("exit") }
    var petExpanded by remember { mutableStateOf(false) }
    var alertExpanded by remember { mutableStateOf(false) }
    var existingGeo by remember { mutableStateOf<Geofence?>(null) }
    val pets by vm.pets.collectAsState()
    val isEditing = geofenceId != null

    val locationPermissions = rememberMultiplePermissionsState(
        listOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
    )

    LaunchedEffect(Unit) { locationPermissions.launchMultiplePermissionRequest() }

    LaunchedEffect(geofenceId) {
        if (geofenceId != null) {
            vm.getGeofenceById(geofenceId)?.also { g ->
                existingGeo = g
                name = g.name; petId = g.petId
                centerLat = g.centerLat; centerLng = g.centerLng
                radius = g.radiusMeters.toInt().toString()
                isActive = g.isActive; alertType = g.alertType
            }
        } else if (preselectedPetId != null) petId = preselectedPetId
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (isEditing) "Editar Geocerca" else "Nueva Geocerca") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Volver") } }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Spacer(Modifier.height(4.dp))

            OutlinedTextField(
                value = name, onValueChange = { name = it },
                label = { Text("Nombre *") }, modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp), singleLine = true,
                leadingIcon = { Icon(Icons.Default.Shield, null) }
            )

            // Pet selector
            ExposedDropdownMenuBox(expanded = petExpanded, onExpandedChange = { petExpanded = it }) {
                OutlinedTextField(
                    value = pets.find { it.id == petId }?.name ?: "Seleccionar mascota",
                    onValueChange = {}, readOnly = true, label = { Text("Mascota *") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(petExpanded) },
                    modifier = Modifier.fillMaxWidth().menuAnchor(), shape = RoundedCornerShape(14.dp)
                )
                ExposedDropdownMenu(expanded = petExpanded, onDismissRequest = { petExpanded = false }) {
                    pets.forEach { pet ->
                        DropdownMenuItem(text = { Text("${pet.name} (${pet.species})") },
                            onClick = { petId = pet.id; petExpanded = false })
                    }
                }
            }

            // ── OSMDroid Map ─────────────────────────────────────────────────
            Text("Toca el mapa para colocar la geocerca", style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant)

            Card(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth().height(300.dp)) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        Configuration.getInstance().userAgentValue = "PetTrack/1.0"
                        MapView(ctx).apply {
                            setTileSource(TileSourceFactory.MAPNIK)
                            setMultiTouchControls(true)
                            controller.setZoom(15.0)
                            controller.setCenter(GeoPoint(centerLat, centerLng))
                        }
                    },
                    update = { mapView ->
                        mapView.overlays.clear()
                        val center = GeoPoint(centerLat, centerLng)
                        val radiusM = radius.toDoubleOrNull() ?: 100.0

                        // Marker
                        val marker = Marker(mapView).apply {
                            position = center
                            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                            title = name.ifBlank { "Geocerca" }
                        }
                        mapView.overlays.add(marker)

                        // Circle polygon approximation
                        val pts = (0..360 step 5).map { deg ->
                            val rad = Math.toRadians(deg.toDouble())
                            val dLat = (radiusM / 111320.0) * cos(rad)
                            val dLng = (radiusM / (111320.0 * cos(Math.toRadians(centerLat)))) *
                                    kotlin.math.sin(rad)
                            GeoPoint(centerLat + dLat, centerLng + dLng)
                        }
                        val circle = Polygon(mapView).apply {
                            points = pts
                            fillColor = 0x226650A4
                            strokeColor = 0xFF6650A4.toInt()
                            strokeWidth = 3f
                        }
                        mapView.overlays.add(circle)

                        // Touch to reposition
                        mapView.setOnTouchListener { _, event ->
                            if (event.action == android.view.MotionEvent.ACTION_UP) {
                                val proj = mapView.projection
                                val gp = proj.fromPixels(event.x.toInt(), event.y.toInt())
                                centerLat = gp.latitude
                                centerLng = gp.longitude
                                mapView.invalidate()
                            }
                            false
                        }
                        mapView.invalidate()
                    }
                )
            }

            // Coordinates display (read-only, updated by map)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Surface(shape = RoundedCornerShape(10.dp), color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.weight(1f)) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("Latitud", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("%.6f".format(centerLat), fontWeight = FontWeight.Medium)
                    }
                }
                Surface(shape = RoundedCornerShape(10.dp), color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.weight(1f)) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("Longitud", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("%.6f".format(centerLng), fontWeight = FontWeight.Medium)
                    }
                }
            }

            // Radius slider + field
            Text("Radio: ${radius.toIntOrNull() ?: 100} metros",
                style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
            Slider(
                value = (radius.toFloatOrNull() ?: 100f).coerceIn(50f, 5000f),
                onValueChange = { radius = it.toInt().toString() },
                valueRange = 50f..5000f,
                steps = 98,
                modifier = Modifier.fillMaxWidth()
            )

            // Alert type
            ExposedDropdownMenuBox(expanded = alertExpanded, onExpandedChange = { alertExpanded = it }) {
                OutlinedTextField(
                    value = when (alertType) { "exit" -> "Alerta al salir"; "enter" -> "Alerta al entrar"; else -> "Al entrar y salir" },
                    onValueChange = {}, readOnly = true, label = { Text("Tipo de alerta") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(alertExpanded) },
                    modifier = Modifier.fillMaxWidth().menuAnchor(), shape = RoundedCornerShape(14.dp)
                )
                ExposedDropdownMenu(expanded = alertExpanded, onDismissRequest = { alertExpanded = false }) {
                    listOf("exit" to "Alerta al salir", "enter" to "Alerta al entrar", "both" to "Al entrar y salir")
                        .forEach { (v, l) -> DropdownMenuItem(text = { Text(l) }, onClick = { alertType = v; alertExpanded = false }) }
                }
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Geocerca activa", style = MaterialTheme.typography.bodyLarge)
                Switch(checked = isActive, onCheckedChange = { isActive = it })
            }

            Button(
                onClick = {
                    val geo = Geofence(
                        id = existingGeo?.id ?: java.util.UUID.randomUUID().toString(),
                        name = name, petId = petId,
                        centerLat = centerLat, centerLng = centerLng,
                        radiusMeters = radius.toFloatOrNull() ?: 100f,
                        isActive = isActive, alertType = alertType,
                        createdAt = existingGeo?.createdAt ?: System.currentTimeMillis()
                    )
                    if (isEditing) vm.updateGeofence(geo) else vm.saveGeofence(geo)
                    onBack()
                },
                enabled = name.isNotBlank() && petId.isNotBlank(),
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.Save, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(if (isEditing) "Guardar Cambios" else "Crear Geocerca")
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}
