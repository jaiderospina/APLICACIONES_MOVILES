package com.example.pet_ultima.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        Pet::class, Geofence::class, GeofenceAlert::class,
        LocationHistory::class, User::class, PetShare::class, SmsLog::class,
        Gf07Message::class, Tracker::class
    ],
    version = 5,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun petDao(): PetDao
    abstract fun petShareDao(): PetShareDao
    abstract fun geofenceDao(): GeofenceDao
    abstract fun geofenceAlertDao(): GeofenceAlertDao
    abstract fun locationHistoryDao(): LocationHistoryDao
    abstract fun userDao(): UserDao
    abstract fun smsLogDao(): SmsLogDao
    abstract fun gf07Dao(): Gf07Dao
    abstract fun trackerDao(): TrackerDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "pettrack_db")
                    .fallbackToDestructiveMigration()
                    .build().also { INSTANCE = it }
            }
        }
    }
}
