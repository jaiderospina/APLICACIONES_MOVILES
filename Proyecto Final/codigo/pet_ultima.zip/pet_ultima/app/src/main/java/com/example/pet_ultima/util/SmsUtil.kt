package com.example.pet_ultima.util

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.telephony.SmsManager
import android.telephony.SmsMessage

object SmsUtil {
    /**
     * Send an SMS to the GF-07 chip.
     * Requires SEND_SMS permission granted at runtime.
     */
    fun sendCommand(context: Context, phoneNumber: String, command: String): Boolean {
        return try {
            val smsManager = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                context.getSystemService(SmsManager::class.java)
            } else {
                @Suppress("DEPRECATION")
                SmsManager.getDefault()
            }
            smsManager.sendTextMessage(phoneNumber, null, command, null, null)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    /**
     * Parse a GF-07 SMS response to extract lat/lng.
     * GF-07 responds with a Google Maps link like:
     * http://maps.google.com/maps?q=4.123456,-74.123456
     */
    fun parseLocation(smsBody: String): Pair<Double, Double>? {
        // Pattern 1: maps?q=LAT,LNG
        val mapsRegex = Regex("""maps\?q=([-\d.]+),([-\d.]+)""")
        mapsRegex.find(smsBody)?.let {
            val lat = it.groupValues[1].toDoubleOrNull()
            val lng = it.groupValues[2].toDoubleOrNull()
            if (lat != null && lng != null) return Pair(lat, lng)
        }
        // Pattern 2: lat:LAT lng:LNG
        val coordRegex = Regex("""lat[:\s]*([-\d.]+).*?lng[:\s]*([-\d.]+)""", RegexOption.IGNORE_CASE)
        coordRegex.find(smsBody)?.let {
            val lat = it.groupValues[1].toDoubleOrNull()
            val lng = it.groupValues[2].toDoubleOrNull()
            if (lat != null && lng != null) return Pair(lat, lng)
        }
        return null
    }
}

/** BroadcastReceiver to capture incoming SMS from the GF-07 */
class SmsReceiverBackup : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        messages.forEach { sms ->
            val body = sms.messageBody ?: return@forEach
            val from = sms.displayOriginatingAddress ?: return@forEach
            // Post a local broadcast for the app to pick up
            val localIntent = Intent("com.example.pet_ultima.SMS_RECEIVED").apply {
                putExtra("from", from)
                putExtra("body", body)
            }
            context.sendBroadcast(localIntent)
        }
    }
}
