package com.example.pet_ultima.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.view.MotionEvent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.app.ActivityCompat
import com.example.pet_ultima.data.db.Geofence
import com.example.pet_ultima.viewmodel.PetViewModel
import com.google.android.gms.location.LocationServices
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polygon
import java.util.UUID
import kotlin.math.cos

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GeofenceMapScreen(
    vm: PetViewModel,
    geofenceId: String?,
    preselectedPetId: String?,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    Configuration.getInstance().userAgentValue = context.packageName

    val pets by vm.pets.collectAsState()
    var existingGeo by remember { mutableStateOf<Geofence?>(null) }

    // Form state
    var name by remember { mutableStateOf("") }
    var petId by remember { mutableStateOf(preselectedPetId ?: "") }
    var radius by remember { mutableStateOf(100f) }
    var alertType by remember { mutableStateOf("exit") }
    var isActive by remember { mutableStateOf(true) }
    var selectedPoint by remember { mutableStateOf<GeoPoint?>(null) }
    var petExpanded by remember { mutableStateOf(false) }
    var alertExpanded by remember { mutableStateOf(false) }
    var showBottomSheet by remember { mutableStateOf(true) }
    var mapView by remember { mutableStateOf<MapView?>(null) }

    LaunchedEffect(geofenceId) {
        if (geofenceId != null) {
            vm.getGeofenceById(geofenceId)?.also { g ->
                existingGeo = g
                name = g.name
                petId = g.petId
                radius = g.radiusMeters
                alertType = g.alertType
                isActive = g.isActive
                selectedPoint = GeoPoint(g.centerLat, g.centerLng)
            }
        } else if (preselectedPetId != null) {
            petId = preselectedPetId
        }
    }

    // Get current location for initial map center
    LaunchedEffect(Unit) {
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            val client = LocationServices.getFusedLocationProviderClient(context)
            client.lastLocation.addOnSuccessListener { loc ->
                if (loc != null && selectedPoint == null) {
                    selectedPoint = GeoPoint(loc.latitude, loc.longitude)
                    mapView?.controller?.setCenter(selectedPoint)
                }
            }
        }
    }

    fun updateMapOverlay(mv: MapView, point: GeoPoint, radiusM: Float) {
        mv.overlays.clear()

        // Circle (polygon approximation)
        val circle = Polygon().apply {
            val pts = (0..72).map { angle ->
                val rad = Math.toRadians(angle * 5.0)
                val dLat = (radiusM / 111320.0) * cos(rad)
                val dLng = (radiusM / (111320.0 * cos(Math.toRadians(point.latitude)))) * Math.sin(rad)
                GeoPoint(point.latitude + dLat, point.longitude + dLng)
            }
            this.points = pts
            fillColor = 0x220000FF
            strokeColor = 0xFF0055FF.toInt()
            strokeWidth = 2.5f
        }
        mv.overlays.add(circle)

        // Center marker
        val marker = Marker(mv).apply {
            position = point
            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
            title = "Centro de la geocerca"
        }
        mv.overlays.add(marker)
        mv.invalidate()
    }

    Box(modifier = Modifier.fillMaxSize()) {
        // Map
        AndroidView(
            factory = { ctx ->
                MapView(ctx).apply {
                    setTileSource(TileSourceFactory.MAPNIK)
                    setMultiTouchControls(true)
                    controller.setZoom(16.0)
                    val center = selectedPoint ?: GeoPoint(4.6097, -74.0817)
                    controller.setCenter(center)
                    mapView = this

                    // Tap to place geofence center
                    overlays.add(object : org.osmdroid.views.overlay.Overlay() {
                        override fun onSingleTapConfirmed(e: MotionEvent, mapView: MapView): Boolean {
                            val proj = mapView.projection
                            val point = proj.fromPixels(e.x.toInt(), e.y.toInt()) as GeoPoint
                            selectedPoint = point
                            updateMapOverlay(mapView, point, radius)
                            return true
                        }
                    })

                    selectedPoint?.let { updateMapOverlay(this, it, radius) }
                }
            },
            update = { mv ->
                mapView = mv
                selectedPoint?.let { updateMapOverlay(mv, it, radius) }
            },
            modifier = Modifier.fillMaxSize()
        )

        // Top bar
        Row(
            modifier = Modifier.fillMaxWidth().statusBarsPadding().padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            FloatingActionButton(onClick = onBack, modifier = Modifier.size(44.dp), containerColor = MaterialTheme.colorScheme.surface) {
                Icon(Icons.Default.ArrowBack, "Volver")
            }
            if (selectedPoint == null) {
                Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f)) {
                    Row(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.TouchApp, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Toca el mapa para colocar la geocerca", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            FloatingActionButton(
                onClick = { showBottomSheet = !showBottomSheet },
                modifier = Modifier.size(44.dp),
                containerColor = MaterialTheme.colorScheme.primaryContainer
            ) {
                Icon(if (showBottomSheet) Icons.Default.KeyboardArrowDown else Icons.Default.KeyboardArrowUp, "Toggle form")
            }
        }

        // Bottom sheet form
        if (showBottomSheet) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Handle bar
                        Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Surface(
                                modifier = Modifier.size(width = 40.dp, height = 4.dp),
                                shape = RoundedCornerShape(2.dp),
                                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                            ) {}
                        }

                        Text("Configurar Geocerca", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)

                        // Coords display
                        selectedPoint?.let { pt ->
                            Surface(shape = RoundedCornerShape(10.dp), color = MaterialTheme.colorScheme.secondaryContainer) {
                                Row(modifier = Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(Icons.Default.LocationOn, null, tint = MaterialTheme.colorScheme.onSecondaryContainer, modifier = Modifier.size(14.dp))
                                    Text("${"%.5f".format(pt.latitude)}, ${"%.5f".format(pt.longitude)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSecondaryContainer)
                                }
                            }
                        } ?: run {
                            Surface(shape = RoundedCornerShape(10.dp), color = MaterialTheme.colorScheme.errorContainer) {
                                Row(modifier = Modifier.fillMaxWidth().padding(10.dp)) {
                                    Icon(Icons.Default.Warning, null, tint = MaterialTheme.colorScheme.onErrorContainer, modifier = Modifier.size(14.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Toca el mapa para seleccionar el centro", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onErrorContainer)
                                }
                            }
                        }

                        OutlinedTextField(value = name, onValueChange = { name = it },
                            label = { Text("Nombre *") }, modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp), singleLine = true)

                        // Pet selector
                        ExposedDropdownMenuBox(expanded = petExpanded, onExpandedChange = { petExpanded = it }) {
                            OutlinedTextField(
                                value = pets.find { it.id == petId }?.name ?: "Seleccionar mascota",
                                onValueChange = {}, readOnly = true,
                                label = { Text("Mascota *") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(petExpanded) },
                                modifier = Modifier.fillMaxWidth().menuAnchor(), shape = RoundedCornerShape(12.dp))
                            ExposedDropdownMenu(expanded = petExpanded, onDismissRequest = { petExpanded = false }) {
                                pets.forEach { pet ->
                                    DropdownMenuItem(text = { Text(pet.name) }, onClick = { petId = pet.id; petExpanded = false })
                                }
                            }
                        }

                        // Radius slider
                        Column {
                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text("Radio", style = MaterialTheme.typography.labelMedium)
                                Text("${radius.toInt()} metros", fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                            }
                            Slider(
                                value = radius,
                                onValueChange = { r ->
                                    radius = r
                                    selectedPoint?.let { mapView?.let { mv -> updateMapOverlay(mv, it, r) } }
                                },
                                valueRange = 50f..2000f,
                                steps = 39,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        // Alert type
                        ExposedDropdownMenuBox(expanded = alertExpanded, onExpandedChange = { alertExpanded = it }) {
                            OutlinedTextField(
                                value = when (alertType) { "exit" -> "🚨 Alerta al salir"; "enter" -> "📥 Alerta al entrar"; else -> "🔔 Entrar y salir" },
                                onValueChange = {}, readOnly = true,
                                label = { Text("Tipo de alerta") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(alertExpanded) },
                                modifier = Modifier.fillMaxWidth().menuAnchor(), shape = RoundedCornerShape(12.dp))
                            ExposedDropdownMenu(expanded = alertExpanded, onDismissRequest = { alertExpanded = false }) {
                                listOf("exit" to "🚨 Alerta al salir", "enter" to "📥 Alerta al entrar", "both" to "🔔 Entrar y salir").forEach { (v, l) ->
                                    DropdownMenuItem(text = { Text(l) }, onClick = { alertType = v; alertExpanded = false })
                                }
                            }
                        }

                        Button(
                            onClick = {
                                val pt = selectedPoint ?: return@Button
                                val geo = Geofence(
                                    id = existingGeo?.id ?: UUID.randomUUID().toString(),
                                    name = name,
                                    petId = petId,
                                    centerLat = pt.latitude,
                                    centerLng = pt.longitude,
                                    radiusMeters = radius,
                                    isActive = isActive,
                                    alertType = alertType,
                                    createdAt = existingGeo?.createdAt ?: System.currentTimeMillis()
                                )
                                if (geofenceId != null) vm.updateGeofence(geo) else vm.saveGeofence(geo)
                                onBack()
                            },
                            enabled = name.isNotBlank() && petId.isNotBlank() && selectedPoint != null,
                            modifier = Modifier.fillMaxWidth().height(52.dp),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(Icons.Default.Save, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(if (geofenceId != null) "Guardar cambios" else "Crear geocerca")
                        }

                        Spacer(Modifier.height(8.dp))
                    }
                }
            }
        }
    }
}
