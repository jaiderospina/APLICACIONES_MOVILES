package com.example.pet_ultima.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.pet_ultima.data.db.Pet
import com.example.pet_ultima.viewmodel.PetViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SharePetScreen(
    vm: PetViewModel,
    petId: String,
    onBack: () -> Unit
) {
    val pets by vm.pets.collectAsState()
    val users by vm.users.collectAsState()
    val activeUser by vm.activeUser.collectAsState()
    val sharedIds by vm.getSharedUserIds(petId).collectAsState(initial = emptyList())
    var selectedIds by remember { mutableStateOf(setOf<String>()) }
    var pet by remember { mutableStateOf<Pet?>(null) }
    var saved by remember { mutableStateOf(false) }

    // Other users (not the owner)
    val otherUsers = users.filter { it.id != activeUser?.id }

    LaunchedEffect(petId) {
        pet = vm.getPetById(petId)
    }
    LaunchedEffect(sharedIds) {
        selectedIds = sharedIds.toSet()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Compartir ${pet?.name ?: "mascota"}") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Volver") } },
                actions = {
                    TextButton(onClick = {
                        vm.setSharesForPet(petId, selectedIds)
                        saved = true
                        onBack()
                    }) {
                        Icon(Icons.Default.Save, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Guardar")
                    }
                }
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            // Header
            Card(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(0.4f))
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        when (pet?.species) {
                            "dog" -> "🐕"; "cat" -> "🐈"; "bird" -> "🐦"; "rabbit" -> "🐇"; else -> "🐾"
                        },
                        fontSize = 36.sp
                    )
                    Column {
                        Text(pet?.name ?: "", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Text(
                            if (selectedIds.isEmpty()) "Solo tú puedes ver esta mascota"
                            else "Compartida con ${selectedIds.size} usuario${if (selectedIds.size != 1) "s" else ""}",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (selectedIds.isEmpty()) MaterialTheme.colorScheme.onSurfaceVariant
                                    else MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            if (otherUsers.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.GroupOff, null, Modifier.size(48.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(8.dp))
                        Text("No hay otros perfiles creados", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            "Crea más perfiles en Gestionar Perfiles",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                Text(
                    "Selecciona con quién compartir",
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                LazyColumn(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(otherUsers, key = { it.id }) { user ->
                        val isSelected = user.id in selectedIds
                        val userColor = try { Color(android.graphics.Color.parseColor(user.colorHex)) }
                                        catch (e: Exception) { MaterialTheme.colorScheme.primary }

                        Card(
                            modifier = Modifier.fillMaxWidth().clickable {
                                selectedIds = if (isSelected) selectedIds - user.id else selectedIds + user.id
                            },
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) userColor.copy(alpha = 0.12f)
                                                else MaterialTheme.colorScheme.surfaceVariant
                            ),
                            border = if (isSelected)
                                androidx.compose.foundation.BorderStroke(2.dp, userColor.copy(0.5f))
                            else null
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(14.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = userColor.copy(0.2f),
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(user.avatarEmoji, fontSize = 24.sp)
                                    }
                                }
                                Column(Modifier.weight(1f)) {
                                    Text(user.name, fontWeight = FontWeight.SemiBold)
                                    if (user.username.isNotBlank()) {
                                        Text("@${user.username}", style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                                Checkbox(
                                    checked = isSelected,
                                    onCheckedChange = { checked ->
                                        selectedIds = if (checked) selectedIds + user.id else selectedIds - user.id
                                    },
                                    colors = CheckboxDefaults.colors(
                                        checkedColor = userColor,
                                        checkmarkColor = Color.White
                                    )
                                )
                            }
                        }
                    }

                    // Select all / none
                    item {
                        Spacer(Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { selectedIds = otherUsers.map { it.id }.toSet() },
                                modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)
                            ) { Text("Seleccionar todos") }
                            OutlinedButton(
                                onClick = { selectedIds = emptySet() },
                                modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)
                            ) { Text("Quitar todos") }
                        }
                    }
                    item { Spacer(Modifier.height(16.dp)) }
                }
            }
        }
    }
}
