package com.example.pet_ultima.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "location_history")
data class LocationHistory(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val petId: String,
    val lat: Double,
    val lng: Double,
    val recordedAt: Long = System.currentTimeMillis()
)
