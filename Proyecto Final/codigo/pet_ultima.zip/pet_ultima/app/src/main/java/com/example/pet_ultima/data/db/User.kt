package com.example.pet_ultima.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "users")
data class User(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val name: String,
    val username: String = "",          // login username
    val passwordHash: String = "",      // SHA-256 hex
    val avatarEmoji: String = "🐾",
    val colorHex: String = "#6650A4",
    val chipPhoneNumber: String = "",   // GF-07 SIM number
    val chipPassword: String = "123456",// GF-07 command password
    val createdAt: Long = System.currentTimeMillis()
)
