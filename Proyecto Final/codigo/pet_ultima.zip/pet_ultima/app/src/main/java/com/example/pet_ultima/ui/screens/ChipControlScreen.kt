package com.example.pet_ultima.ui.screens

import android.Manifest
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.pet_ultima.data.db.Pet
import com.example.pet_ultima.viewmodel.PetViewModel
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberMultiplePermissionsState
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class, ExperimentalPermissionsApi::class)
@Composable
fun ChipControlScreen(vm: PetViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val pets by vm.pets.collectAsState()
    val activeUser by vm.activeUser.collectAsState()
    val smsLogs by vm.getAllSmsLogs().collectAsState(initial = emptyList())

    var selectedPet by remember { mutableStateOf<Pet?>(null) }
    var petExpanded by remember { mutableStateOf(false) }
    var chipNumber by remember { mutableStateOf("") }
    var chipPassword by remember { mutableStateOf("123456") }
    var customCommand by remember { mutableStateOf("") }

    val smsPermissions = rememberMultiplePermissionsState(
        listOf(Manifest.permission.SEND_SMS, Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS)
    )
    val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    LaunchedEffect(selectedPet) {
        selectedPet?.let { pet ->
            chipNumber = pet.chipPhoneNumber.ifBlank { activeUser?.chipPhoneNumber ?: "" }
            chipPassword = activeUser?.chipPassword ?: "123456"
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Control GF-07") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Volver") } }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // SMS Permission
            if (!smsPermissions.allPermissionsGranted) {
                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Permiso SMS requerido", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onErrorContainer)
                            Text("Para controlar el chip GF-07 necesitamos enviar y recibir SMS.", color = MaterialTheme.colorScheme.onErrorContainer, style = MaterialTheme.typography.bodySmall)
                            Button(onClick = { smsPermissions.launchMultiplePermissionRequest() }, shape = RoundedCornerShape(10.dp)) {
                                Text("Conceder permisos")
                            }
                        }
                    }
                }
            }

            // Pet selector
            item {
                ExposedDropdownMenuBox(expanded = petExpanded, onExpandedChange = { petExpanded = it }) {
                    OutlinedTextField(
                        value = selectedPet?.name ?: "Seleccionar mascota",
                        onValueChange = {}, readOnly = true, label = { Text("Mascota") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(petExpanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor(), shape = RoundedCornerShape(14.dp)
                    )
                    ExposedDropdownMenu(expanded = petExpanded, onDismissRequest = { petExpanded = false }) {
                        pets.forEach { pet ->
                            DropdownMenuItem(text = { Text(pet.name) }, onClick = { selectedPet = pet; petExpanded = false })
                        }
                    }
                }
            }

            // Chip config
            item {
                Card(shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Configuración del chip", fontWeight = FontWeight.SemiBold)
                        OutlinedTextField(
                            value = chipNumber, onValueChange = { chipNumber = it },
                            label = { Text("Número SIM del chip") },
                            leadingIcon = { Icon(Icons.Default.SimCard, null) },
                            modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), singleLine = true
                        )
                        OutlinedTextField(
                            value = chipPassword, onValueChange = { chipPassword = it },
                            label = { Text("Contraseña del chip (default: 123456)") },
                            leadingIcon = { Icon(Icons.Default.Key, null) },
                            modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), singleLine = true
                        )
                        // Save to pet
                        selectedPet?.let { pet ->
                            OutlinedButton(
                                onClick = { vm.updatePet(pet.copy(chipPhoneNumber = chipNumber)) },
                                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.Save, null, Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Guardar número en mascota")
                            }
                        }
                    }
                }
            }

            // Command buttons
            item {
                Card(shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Comandos GF-07", fontWeight = FontWeight.SemiBold)
                        val enabled = chipNumber.isNotBlank() && smsPermissions.allPermissionsGranted && selectedPet != null

                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(
                                onClick = { selectedPet?.let { vm.requestChipLocation(context, it.copy(chipPhoneNumber = chipNumber)) } },
                                enabled = enabled, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.LocationOn, null, Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Ubicación", maxLines = 1)
                            }
                            Button(
                                onClick = { selectedPet?.let { vm.startChipTracking(context, it.copy(chipPhoneNumber = chipNumber)) } },
                                enabled = enabled, modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary)
                            ) {
                                Icon(Icons.Default.PlayArrow, null, Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Rastrear", maxLines = 1)
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedButton(
                                onClick = { selectedPet?.let { vm.stopChipTracking(context, it.copy(chipPhoneNumber = chipNumber)) } },
                                enabled = enabled, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.Stop, null, Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Detener", maxLines = 1)
                            }
                            OutlinedButton(
                                onClick = {
                                    selectedPet?.let {
                                        vm.sendSmsToChip(context, chipNumber, "${chipPassword} reset", it.id, "Reiniciar chip")
                                    }
                                },
                                enabled = enabled, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                            ) {
                                Icon(Icons.Default.RestartAlt, null, Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Reiniciar", maxLines = 1)
                            }
                        }

                        HorizontalDivider()

                        // Custom command
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = customCommand, onValueChange = { customCommand = it },
                                label = { Text("Comando manual") },
                                modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp), singleLine = true
                            )
                            IconButton(
                                onClick = {
                                    if (customCommand.isNotBlank() && chipNumber.isNotBlank() && selectedPet != null) {
                                        vm.sendSmsToChip(context, chipNumber, customCommand, selectedPet!!.id)
                                        customCommand = ""
                                    }
                                },
                                enabled = enabled && customCommand.isNotBlank()
                            ) { Icon(Icons.Default.Send, "Enviar") }
                        }
                    }
                }
            }

            // SMS Log
            item {
                Text("Registro de SMS", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleSmall)
            }

            if (smsLogs.isEmpty()) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                        Text("Sin registros aún", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            } else {
                items(smsLogs.take(30), key = { it.id }) { log ->
                    val isSent = log.direction == "sent"
                    Card(
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSent) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                            else MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)
                        )
                    ) {
                        Row(modifier = Modifier.padding(10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(
                                if (isSent) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                                null, modifier = Modifier.size(16.dp),
                                tint = if (isSent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(log.message, style = MaterialTheme.typography.bodySmall)
                                if (log.parsedLat != null) {
                                    Text("📍 %.5f, %.5f".format(log.parsedLat, log.parsedLng),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.Medium)
                                }
                            }
                            Text(sdf.format(Date(log.timestamp)), style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            item { Spacer(Modifier.height(16.dp)) }
        }
    }
}
