package com.example.pet_ultima.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface PetDao {
    // Own pets + explicitly shared with this user
    @Query("""
        SELECT DISTINCT p.* FROM pets p
        LEFT JOIN pet_shares ps ON p.id = ps.petId AND ps.sharedWithUserId = :userId
        WHERE p.userId = :userId OR ps.sharedWithUserId = :userId
        ORDER BY p.createdAt DESC
    """)
    fun getPetsForUser(userId: String): Flow<List<Pet>>

    @Query("SELECT * FROM pets ORDER BY createdAt DESC")
    fun getAllPets(): Flow<List<Pet>>

    @Query("SELECT * FROM pets WHERE id = :id")
    suspend fun getPetById(id: String): Pet?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPet(pet: Pet)

    @Update
    suspend fun updatePet(pet: Pet)

    @Query("DELETE FROM pets WHERE id = :id")
    suspend fun deletePet(id: String)
}

@Dao
interface GeofenceDao {
    @Query("SELECT * FROM geofences WHERE userId = :userId ORDER BY createdAt DESC")
    fun getGeofencesForUser(userId: String): Flow<List<Geofence>>

    @Query("SELECT * FROM geofences ORDER BY createdAt DESC")
    fun getAllGeofences(): Flow<List<Geofence>>

    @Query("SELECT * FROM geofences WHERE petId = :petId")
    fun getGeofencesByPet(petId: String): Flow<List<Geofence>>

    @Query("SELECT * FROM geofences WHERE id = :id")
    suspend fun getGeofenceById(id: String): Geofence?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGeofence(geofence: Geofence)

    @Update
    suspend fun updateGeofence(geofence: Geofence)

    @Query("DELETE FROM geofences WHERE id = :id")
    suspend fun deleteGeofence(id: String)

    @Query("SELECT COUNT(*) FROM geofences WHERE petId = :petId")
    suspend fun getGeofenceCountForPet(petId: String): Int
}

@Dao
interface GeofenceAlertDao {
    @Query("SELECT * FROM geofence_alerts ORDER BY createdAt DESC LIMIT 50")
    fun getAllAlerts(): Flow<List<GeofenceAlert>>

    @Query("SELECT COUNT(*) FROM geofence_alerts WHERE isRead = 0")
    fun getUnreadCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlert(alert: GeofenceAlert)

    @Query("UPDATE geofence_alerts SET isRead = 1 WHERE id = :id")
    suspend fun markAsRead(id: String)

    @Query("UPDATE geofence_alerts SET isRead = 1")
    suspend fun markAllAsRead()
}

@Dao
interface LocationHistoryDao {
    @Query("SELECT * FROM location_history WHERE petId = :petId ORDER BY recordedAt DESC LIMIT 100")
    fun getHistoryForPet(petId: String): Flow<List<LocationHistory>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLocation(location: LocationHistory)

    @Query("DELETE FROM location_history WHERE petId = :petId")
    suspend fun clearHistoryForPet(petId: String)
}

@Dao
interface SmsLogDao {
    @Query("SELECT * FROM sms_logs WHERE petId = :petId ORDER BY timestamp DESC LIMIT 50")
    fun getLogsForPet(petId: String): Flow<List<SmsLog>>

    @Query("SELECT * FROM sms_logs ORDER BY timestamp DESC LIMIT 100")
    fun getAllLogs(): Flow<List<SmsLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: SmsLog)
}
