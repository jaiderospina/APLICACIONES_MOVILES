package com.example.pet_ultima.sms

import android.content.Context
import android.telephony.SmsManager

object GF07Controller {

    /** Send raw SMS command to the chip */
    fun sendCommand(context: Context, phoneNumber: String, command: String) {
        if (phoneNumber.isBlank()) return
        try {
            val smsManager = SmsManager.getDefault()
            smsManager.sendTextMessage(phoneNumber, null, command, null, null)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // ── GF-07 commands ───────────────────────────────────────────────────────
    /** Request current location (responds with Google Maps link) */
    fun requestLocation(context: Context, phone: String) =
        sendCommand(context, phone, "dw")

    /** Activate continuous tracking (sends location every X seconds) */
    fun startTracking(context: Context, phone: String, chipPass: String) =
        sendCommand(context, phone, "${chipPass} begin")

    /** Stop continuous tracking */
    fun stopTracking(context: Context, phone: String, chipPass: String) =
        sendCommand(context, phone, "${chipPass} stop")

    /** Switch to tracker mode (sends location every minute) */
    fun trackerMode(context: Context, phone: String, chipPass: String) =
        sendCommand(context, phone, "${chipPass} tracker")

    /** Set a phone number to receive auto-alerts */
    fun setAdminNumber(context: Context, phone: String, chipPass: String, adminPhone: String) =
        sendCommand(context, phone, "${chipPass} admin${adminPhone}")

    /** Reset to factory defaults */
    fun factoryReset(context: Context, phone: String, chipPass: String) =
        sendCommand(context, phone, "${chipPass} reset")

    /** Change chip password */
    fun changePassword(context: Context, phone: String, oldPass: String, newPass: String) =
        sendCommand(context, phone, "${oldPass} password${newPass}")

    /** Parse a Google Maps URL from GF-07 SMS response */
    fun parseLocationFromSms(body: String): Pair<Double, Double>? {
        // GF-07 responds with: http://maps.google.com/maps?q=lat,lng
        val regex = Regex("q=(-?\\d+\\.\\d+),(-?\\d+\\.\\d+)")
        val match = regex.find(body) ?: return null
        return try {
            Pair(match.groupValues[1].toDouble(), match.groupValues[2].toDouble())
        } catch (e: Exception) { null }
    }
}
