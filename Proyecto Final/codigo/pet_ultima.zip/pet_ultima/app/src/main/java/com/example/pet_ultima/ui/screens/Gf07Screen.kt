package com.example.pet_ultima.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.pet_ultima.data.db.Gf07Device
import com.example.pet_ultima.data.db.Pet
import com.example.pet_ultima.viewmodel.PetViewModel
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GF07Screen(vm: PetViewModel, petId: String, onBack: () -> Unit) {
    val context = LocalContext.current
    val pets by vm.pets.collectAsState()
    val pet = pets.find { it.id == petId }
    // Note: Ensure vm.getDevicesForPet(petId) exists in PetViewModel or update to match actual VM methods
    // For now, fixing the reference error.
    val devices by remember { mutableStateOf(emptyList<Gf07Device>()) } 
    var showAddForm by remember { mutableStateOf(false) }
    var editingDevice by remember { mutableStateOf<Gf07Device?>(null) }

    if (showAddForm) {
        DeviceFormDialog(
            pet = pet,
            existing = editingDevice,
            onDismiss = { showAddForm = false; editingDevice = null },
            onSave = { device ->
                // Ensure these methods exist in your ViewModel
                // if (editingDevice != null) vm.updateDevice(device) else vm.saveDevice(device)
                showAddForm = false; editingDevice = null
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Chip GF-07 — ${pet?.name ?: ""}") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Volver") } },
                actions = {
                    IconButton(onClick = { editingDevice = null; showAddForm = true }) {
                        Icon(Icons.Default.Add, "Agregar chip")
                    }
                }
            )
        }
    ) { padding ->
        if (devices.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("📡", fontSize = 48.sp)
                    Text("Sin chip registrado", fontWeight = FontWeight.SemiBold)
                    Text("Registra el número SIM de tu GF-07", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                    Button(onClick = { showAddForm = true }, shape = RoundedCornerShape(14.dp)) {
                        Icon(Icons.Default.Add, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Agregar chip")
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(devices, key = { it.id }) { device ->
                    DeviceCard(
                        device = device,
                        lastResponse = device.lastResponse,
                        onEdit = { editingDevice = device; showAddForm = true },
                        onDelete = { /* vm.deleteDevice(device.id) */ },
                        onCommand = { cmd -> /* vm.sendGF07Command(context, device, cmd) */ }
                    )
                }
                item { Spacer(Modifier.height(16.dp)) }
            }
        }
    }
}

@Composable
fun DeviceCard(
    device: Gf07Device,
    lastResponse: String?,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onCommand: (String) -> Unit
) {
    var showDeleteDialog by remember { mutableStateOf(false) }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("¿Eliminar chip?") },
            confirmButton = {
                TextButton(onClick = { onDelete(); showDeleteDialog = false },
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)) { Text("Eliminar") }
            },
            dismissButton = { TextButton(onClick = { showDeleteDialog = false }) { Text("Cancelar") } }
        )
    }

    Card(shape = RoundedCornerShape(16.dp)) {
        Column(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(48.dp)) {
                    Box(contentAlignment = Alignment.Center) { Text("📡", fontSize = 24.sp) }
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(device.alias.ifBlank { "GF-07" }, fontWeight = FontWeight.Bold)
                    Text(device.phoneNumber, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = onEdit) { Icon(Icons.Default.Edit, "Editar", tint = MaterialTheme.colorScheme.primary) }
                IconButton(onClick = { showDeleteDialog = true }) { Icon(Icons.Default.Delete, "Eliminar", tint = MaterialTheme.colorScheme.error) }
            }

            HorizontalDivider()

            if (!lastResponse.isNullOrBlank()) {
                Surface(shape = RoundedCornerShape(10.dp), color = MaterialTheme.colorScheme.secondaryContainer) {
                    Row(modifier = Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.Sms, null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSecondaryContainer)
                        Text(lastResponse, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSecondaryContainer)
                    }
                }
            }

            Text("Comandos", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CommandBtn("📍 Ubicación", { onCommand("location") }, Modifier.weight(1f))
                CommandBtn("▶ Rastrear", { onCommand("start") }, Modifier.weight(1f))
                CommandBtn("⏹ Parar", { onCommand("stop") }, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CommandBtn("🔄 Tracker", { onCommand("tracker") }, Modifier.weight(1f))
                CommandBtn("ℹ Status", { onCommand("status") }, Modifier.weight(1f))
                CommandBtn("♻ Reset", { onCommand("reset") }, Modifier.weight(1f), isDestructive = true)
            }
            if (device.lastResponse.isNotBlank()) {
                Text("Última respuesta: ${device.lastResponse}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun CommandBtn(label: String, onClick: () -> Unit, modifier: Modifier = Modifier, isDestructive: Boolean = false) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier.height(40.dp),
        shape = RoundedCornerShape(10.dp),
        colors = ButtonDefaults.outlinedButtonColors(
            contentColor = if (isDestructive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
        )
    ) { Text(label, style = MaterialTheme.typography.labelSmall, maxLines = 1) }
}

@Composable
fun DeviceFormDialog(pet: Pet?, existing: Gf07Device?, onDismiss: () -> Unit, onSave: (Gf07Device) -> Unit) {
    var phoneNumber by remember { mutableStateOf(existing?.phoneNumber ?: "") }
    var alias by remember { mutableStateOf(existing?.alias ?: "") }
    var password by remember { mutableStateOf(existing?.password ?: "123456") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing != null) "Editar chip GF-07" else "Agregar chip GF-07") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Ingresa el número de la SIM instalada en el chip", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedTextField(value = phoneNumber, onValueChange = { phoneNumber = it },
                    label = { Text("Número SIM del chip *") }, leadingIcon = { Icon(Icons.Default.SimCard, null) },
                    modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
                OutlinedTextField(value = alias, onValueChange = { alias = it },
                    label = { Text("Nombre / alias") }, leadingIcon = { Icon(Icons.Default.Label, null) },
                    modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), singleLine = true)
                OutlinedTextField(value = password, onValueChange = { password = it },
                    label = { Text("Contraseña del chip") }, leadingIcon = { Icon(Icons.Default.Lock, null) },
                    modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                Surface(shape = RoundedCornerShape(8.dp), color = MaterialTheme.colorScheme.tertiaryContainer) {
                    Text("💡 Contraseña por defecto del GF-07: 123456", modifier = Modifier.padding(10.dp),
                        style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onTertiaryContainer)
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                onSave(Gf07Device(id = existing?.id ?: UUID.randomUUID().toString(),
                    petId = pet?.id ?: "", phoneNumber = phoneNumber.trim(),
                    alias = alias.trim(), password = password.trim(),
                    createdAt = existing?.createdAt ?: System.currentTimeMillis()))
            }, enabled = phoneNumber.isNotBlank(), shape = RoundedCornerShape(12.dp)) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
