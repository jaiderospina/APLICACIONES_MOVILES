package com.example.pet_ultima.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.pet_ultima.data.db.Pet
import com.example.pet_ultima.data.db.PetShare
import com.example.pet_ultima.viewmodel.PetViewModel

@Composable
fun PetShareDialog(
    vm: PetViewModel,
    pet: Pet,
    onDismiss: () -> Unit
) {
    val users by vm.users.collectAsState()
    val shares by vm.getSharesForPet(pet.id).collectAsState(initial = emptyList())
    val activeUser by vm.activeUser.collectAsState()

    // Build mutable set of selected user IDs (excluding current user/owner)
    val sharedIds = remember(shares) { shares.map { it.sharedWithUserId }.toMutableStateList() }

    val otherUsers = users.filter { it.id != pet.userId && it.id != activeUser?.id }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Compartir a ${pet.name}")
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (otherUsers.isEmpty()) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("👥", fontSize = 32.sp)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "No hay otros perfiles para compartir. Crea más perfiles en Gestionar perfiles.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    Text(
                        "Selecciona los perfiles que podrán ver a ${pet.name}:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    LazyColumn(
                        modifier = Modifier.heightIn(max = 300.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(otherUsers, key = { it.id }) { user ->
                            val isSelected = user.id in sharedIds
                            val color = try { Color(android.graphics.Color.parseColor(user.colorHex)) }
                            catch (e: Exception) { MaterialTheme.colorScheme.primary }

                            Card(
                                modifier = Modifier.fillMaxWidth().clickable {
                                    if (isSelected) sharedIds.remove(user.id)
                                    else sharedIds.add(user.id)
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isSelected)
                                        color.copy(alpha = 0.12f)
                                    else MaterialTheme.colorScheme.surfaceVariant
                                ),
                                border = if (isSelected)
                                    androidx.compose.foundation.BorderStroke(2.dp, color.copy(alpha = 0.5f))
                                else null
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = color.copy(alpha = 0.2f),
                                        modifier = Modifier.size(40.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text(user.avatarEmoji, fontSize = 20.sp)
                                        }
                                    }
                                    Text(user.name, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                                    if (isSelected) {
                                        Icon(Icons.Default.CheckCircle, null,
                                            tint = color, modifier = Modifier.size(20.dp))
                                    } else {
                                        Icon(Icons.Default.RadioButtonUnchecked, null,
                                            tint = MaterialTheme.colorScheme.outline, modifier = Modifier.size(20.dp))
                                    }
                                }
                            }
                        }
                    }

                    if (sharedIds.isNotEmpty()) {
                        Text(
                            "Compartida con ${sharedIds.size} perfil${if (sharedIds.size != 1) "es" else ""}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    vm.setSharesForPet(pet.id, sharedIds.toSet())
                    onDismiss()
                },
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Share, null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Guardar")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
