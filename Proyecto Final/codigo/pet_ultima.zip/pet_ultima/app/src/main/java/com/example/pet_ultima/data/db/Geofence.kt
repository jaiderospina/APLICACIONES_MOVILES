package com.example.pet_ultima.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "geofences")
data class Geofence(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val userId: String = "",
    val name: String,
    val petId: String,
    val centerLat: Double,
    val centerLng: Double,
    val radiusMeters: Float = 100f,
    val isActive: Boolean = true,
    val alertType: String = "exit",
    val createdAt: Long = System.currentTimeMillis()
)
