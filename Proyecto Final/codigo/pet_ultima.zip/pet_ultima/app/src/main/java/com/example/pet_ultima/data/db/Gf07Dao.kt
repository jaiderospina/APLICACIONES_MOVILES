package com.example.pet_ultima.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface Gf07Dao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: Gf07Message)

    @Query("SELECT * FROM gf07_messages WHERE userId = :userId ORDER BY createdAt DESC")
    fun getMessagesForUser(userId: String): Flow<List<Gf07Message>>

    @Query("SELECT * FROM gf07_messages ORDER BY createdAt DESC")
    fun getAllMessages(): Flow<List<Gf07Message>>

    @Query("DELETE FROM gf07_messages")
    suspend fun deleteAll()
}
