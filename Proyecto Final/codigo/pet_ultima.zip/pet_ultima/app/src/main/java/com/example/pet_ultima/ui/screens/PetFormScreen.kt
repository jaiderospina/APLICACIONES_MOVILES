package com.example.pet_ultima.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.pet_ultima.data.db.Pet
import com.example.pet_ultima.viewmodel.PetViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PetFormScreen(
    vm: PetViewModel,
    petId: String?,
    onBack: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    var species by remember { mutableStateOf("dog") }
    var breed by remember { mutableStateOf("") }
    var age by remember { mutableStateOf("") }
    var weight by remember { mutableStateOf("") }
    var color by remember { mutableStateOf("") }
    var microchipId by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var photoUri by remember { mutableStateOf("") }
    var isShared by remember { mutableStateOf(false) }
    var gf07Number by remember { mutableStateOf("") }
    var gf07Password by remember { mutableStateOf("123456") }
    var existingPet by remember { mutableStateOf<Pet?>(null) }
    var expanded by remember { mutableStateOf(false) }

    val isEditing = petId != null

    LaunchedEffect(petId) {
        if (petId != null) {
            vm.getPetById(petId)?.also { p ->
                existingPet = p
                name = p.name
                species = p.species
                breed = p.breed
                age = p.age?.toString() ?: ""
                weight = p.weight?.toString() ?: ""
                color = p.color
                microchipId = p.microchipId
                notes = p.notes
                photoUri = p.photoUri
                isShared = p.isShared
                gf07Number = p.chipPhoneNumber
                gf07Password = p.chipPassword
            }
        }
    }

    val photoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { photoUri = it.toString() }
    }

    val speciesOptions = listOf(
        "dog" to "🐕 Perro",
        "cat" to "🐈 Gato",
        "bird" to "🐦 Ave",
        "rabbit" to "🐇 Conejo",
        "other" to "🐾 Otro"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (isEditing) "Editar Mascota" else "Nueva Mascota") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Volver") }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Photo picker
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Box(
                    modifier = Modifier
                        .size(100.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .clickable { photoLauncher.launch("image/*") },
                    contentAlignment = Alignment.Center
                ) {
                    if (photoUri.isNotBlank()) {
                        AsyncImage(
                            model = photoUri,
                            contentDescription = "Foto",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Surface(
                            modifier = Modifier.fillMaxSize(),
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.CameraAlt, "Agregar foto", modifier = Modifier.size(36.dp))
                            }
                        }
                    }
                }
            }

            // Name
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Nombre *") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                singleLine = true
            )

            // Species dropdown
            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
                OutlinedTextField(
                    value = speciesOptions.find { it.first == species }?.second ?: species,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Especie *") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                    modifier = Modifier.fillMaxWidth().menuAnchor(),
                    shape = RoundedCornerShape(14.dp)
                )
                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    speciesOptions.forEach { (val_, label) ->
                        DropdownMenuItem(
                            text = { Text(label) },
                            onClick = { species = val_; expanded = false }
                        )
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = breed,
                    onValueChange = { breed = it },
                    label = { Text("Raza") },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp),
                    singleLine = true
                )
                OutlinedTextField(
                    value = color,
                    onValueChange = { color = it },
                    label = { Text("Color") },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp),
                    singleLine = true
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = age,
                    onValueChange = { age = it },
                    label = { Text("Edad (años)") },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true
                )
                OutlinedTextField(
                    value = weight,
                    onValueChange = { weight = it },
                    label = { Text("Peso (kg)") },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true
                )
            }

            OutlinedTextField(
                value = microchipId,
                onValueChange = { microchipId = it },
                label = { Text("Microchip ID") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                singleLine = true
            )


            // GF-07 Chip section
            HorizontalDivider()
            Text(
                "🛰️ Chip GPS GF-07 (opcional)",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary
            )
            OutlinedTextField(
                value = gf07Number,
                onValueChange = { gf07Number = it },
                label = { Text("Número SIM del chip") },
                placeholder = { Text("+573001234567") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                singleLine = true,
                leadingIcon = { Icon(Icons.Default.SimCard, null) }
            )
            OutlinedTextField(
                value = gf07Password,
                onValueChange = { gf07Password = it },
                label = { Text("Contraseña del chip") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                singleLine = true,
                leadingIcon = { Icon(Icons.Default.Password, null) }
            )
            HorizontalDivider()

            // Shared toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Mascota compartida", style = MaterialTheme.typography.bodyLarge)
                    Text(
                        "Visible para todos los perfiles",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(checked = isShared, onCheckedChange = { isShared = it })
            }

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Notas") },
                modifier = Modifier.fillMaxWidth().height(120.dp),
                shape = RoundedCornerShape(14.dp),
                maxLines = 4
            )

            Button(
                onClick = {
                    val pet = Pet(
                        id = existingPet?.id ?: java.util.UUID.randomUUID().toString(),
                        name = name,
                        species = species,
                        breed = breed,
                        age = age.toFloatOrNull(),
                        weight = weight.toFloatOrNull(),
                        color = color,
                        microchipId = microchipId,
                        notes = notes,
                        photoUri = photoUri,
                        isShared = isShared,
                        chipPhoneNumber = gf07Number,
                        chipPassword = gf07Password,
                        status = existingPet?.status ?: "active",
                        lastKnownLat = existingPet?.lastKnownLat,
                        lastKnownLng = existingPet?.lastKnownLng,
                        lastLocationUpdate = existingPet?.lastLocationUpdate,
                        createdAt = existingPet?.createdAt ?: System.currentTimeMillis()
                    )
                    if (isEditing) vm.updatePet(pet) else vm.savePet(pet)
                    onBack()
                },
                enabled = name.isNotBlank(),
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.Save, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(if (isEditing) "Guardar Cambios" else "Agregar Mascota")
            }

            Spacer(Modifier.height(16.dp))
        }
    }
}
