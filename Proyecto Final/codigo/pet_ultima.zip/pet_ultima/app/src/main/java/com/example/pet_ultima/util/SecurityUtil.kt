package com.example.pet_ultima.util

import java.security.MessageDigest

object SecurityUtil {
    fun hashPassword(password: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(password.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun verifyPassword(input: String, hash: String): Boolean =
        hashPassword(input) == hash

    fun isValidPassword(password: String): Boolean = password.length >= 4
}
