package com.example.pet_ultima.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.pet_ultima.data.db.Geofence
import com.example.pet_ultima.navigation.Screen
import com.example.pet_ultima.viewmodel.PetViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GeofenceDetailScreen(vm: PetViewModel, geofenceId: String, onNavigate: (String) -> Unit, onBack: () -> Unit) {
    var geo by remember { mutableStateOf<Geofence?>(null) }
    var showDelete by remember { mutableStateOf(false) }
    val pets by vm.pets.collectAsState()
    val geofences by vm.geofences.collectAsState()

    LaunchedEffect(geofenceId, geofences) {
        geo = vm.getGeofenceById(geofenceId)
    }

    if (showDelete) {
        AlertDialog(
            onDismissRequest = { showDelete = false },
            title = { Text("¿Eliminar geocerca?") },
            text = { Text("Esta acción no se puede deshacer.") },
            confirmButton = {
                TextButton(onClick = { vm.deleteGeofence(geofenceId); onBack() },
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)) {
                    Text("Eliminar")
                }
            },
            dismissButton = { TextButton(onClick = { showDelete = false }) { Text("Cancelar") } }
        )
    }

    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(geo?.name ?: "Geocerca") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Volver") } },
                actions = {
                    IconButton(onClick = { onNavigate(Screen.GeofenceForm.createRoute(geofenceId)) }) { Icon(Icons.Default.Edit, "Editar") }
                    IconButton(onClick = { showDelete = true }) { Icon(Icons.Default.Delete, "Eliminar", tint = MaterialTheme.colorScheme.error) }
                }
            )
        }
    ) { padding ->
        val g = geo
        if (g == null) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            return@Scaffold
        }
        val pet = pets.find { it.id == g.petId }

        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Card(shape = RoundedCornerShape(16.dp)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(48.dp)) {
                            Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.Shield, null, tint = MaterialTheme.colorScheme.primary) }
                        }
                        Column {
                            Text(g.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            Text(if (g.isActive) "Activa" else "Inactiva", color = if (g.isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    HorizontalDivider()
                    InfoRow(label = "Mascota", value = pet?.name ?: "Desconocida", icon = Icons.Default.Pets)
                    InfoRow(label = "Radio", value = "${g.radiusMeters.toInt()} metros", icon = Icons.Default.RadioButtonUnchecked)
                    InfoRow(label = "Tipo de alerta", value = when (g.alertType) { "exit" -> "Al salir"; "enter" -> "Al entrar"; else -> "Al entrar y salir" }, icon = Icons.Default.Notifications)
                    InfoRow(label = "Latitud", value = "%.6f".format(g.centerLat), icon = Icons.Default.LocationOn)
                    InfoRow(label = "Longitud", value = "%.6f".format(g.centerLng), icon = Icons.Default.LocationOn)
                }
            }

            // Toggle active
            Card(shape = RoundedCornerShape(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Geocerca activa", fontWeight = FontWeight.Medium)
                    Switch(
                        checked = g.isActive,
                        onCheckedChange = { vm.updateGeofence(g.copy(isActive = it)) }
                    )
                }
            }

            if (pets.isNotEmpty() && pet != null) {
                Button(
                    onClick = { vm.fireGeofenceAlert(context, pet.id, g.id, "exit") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer, contentColor = MaterialTheme.colorScheme.onSecondaryContainer)
                ) {
                    Icon(Icons.Default.AddAlert, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Simular alerta de salida")
                }
            }
        }
    }
}

@Composable
fun InfoRow(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Icon(icon, null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall, modifier = Modifier.width(80.dp))
        Text(value, fontWeight = FontWeight.Medium, style = MaterialTheme.typography.bodyMedium)
    }
}
