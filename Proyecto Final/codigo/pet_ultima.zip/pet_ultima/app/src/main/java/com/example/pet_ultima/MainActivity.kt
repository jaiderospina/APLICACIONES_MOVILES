package com.example.pet_ultima

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.example.pet_ultima.data.db.AppDatabase
import com.example.pet_ultima.data.repository.PetRepository
import com.example.pet_ultima.navigation.Screen
import com.example.pet_ultima.ui.screens.*
import com.example.pet_ultima.ui.theme.Pet_ultimaTheme
import com.example.pet_ultima.util.NotificationHelper
import com.example.pet_ultima.viewmodel.PetViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        NotificationHelper.createChannels(this)
        val db = AppDatabase.getDatabase(this)
        val repo = PetRepository(db)
        setContent {
            Pet_ultimaTheme { PetTrackApp(repo) }
        }
    }
}

data class BottomNavItem(val route: String, val icon: ImageVector, val label: String)

@Composable
fun PetTrackApp(repo: PetRepository) {
    val vm: PetViewModel = viewModel(factory = PetViewModel.Factory(repo))
    val navController = rememberNavController()
    val unreadCount by vm.unreadAlertCount.collectAsState()

    val bottomItems = listOf(
        BottomNavItem(Screen.Dashboard.route, Icons.Default.Home, "Inicio"),
        BottomNavItem(Screen.PetList.route, Icons.Default.Pets, "Mascotas"),
        BottomNavItem(Screen.Geofences.route, Icons.Default.Shield, "Geocercas"),
        BottomNavItem(Screen.Alerts.route, Icons.Default.Notifications, "Alertas"),
        BottomNavItem(Screen.Profile.route, Icons.Default.Person, "Perfil"),
    )
    val topLevelRoutes = bottomItems.map { it.route }
    val navBackStack by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStack?.destination?.route?.substringBefore("?")?.substringBefore("/")
    val showBottomBar = currentRoute in topLevelRoutes

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                NavigationBar {
                    bottomItems.forEach { item ->
                        NavigationBarItem(
                            selected = currentRoute == item.route,
                            onClick = {
                                navController.navigate(item.route) {
                                    popUpTo(Screen.Dashboard.route) { saveState = true }
                                    launchSingleTop = true; restoreState = true
                                }
                            },
                            icon = {
                                if (item.route == Screen.Alerts.route && unreadCount > 0) {
                                    BadgedBox(badge = { Badge { Text(unreadCount.toString()) } }) {
                                        Icon(item.icon, item.label)
                                    }
                                } else Icon(item.icon, item.label)
                            },
                            label = { Text(item.label) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Login.route,
            modifier = Modifier.fillMaxSize().padding(padding)
        ) {
            // ── Auth ─────────────────────────────────────────────────────────
            composable(Screen.Login.route) {
                LoginScreen(vm = vm) { user ->
                    vm.setActiveUser(user)
                    navController.navigate(Screen.Dashboard.route) {
                        popUpTo(Screen.Login.route) { inclusive = true }
                    }
                }
            }
            composable(Screen.UserSelect.route) {
                UserSelectScreen(
                    vm = vm,
                    onUserSelected = { user ->
                        vm.setActiveUser(user)
                        navController.navigate(Screen.Dashboard.route) {
                            popUpTo(Screen.UserSelect.route) { inclusive = true }
                        }
                    },
                    onManageUsers = { navController.navigate(Screen.ManageUsers.route) }
                )
            }
            composable(Screen.ManageUsers.route) {
                ManageUsersScreen(vm = vm, onBack = { navController.popBackStack() })
            }

            // ── Main app ─────────────────────────────────────────────────────
            composable(Screen.Dashboard.route) {
                DashboardScreen(vm) { route -> navController.navigate(route) }
            }
            composable(Screen.PetList.route) {
                PetListScreen(vm) { route -> navController.navigate(route) }
            }
            composable(
                Screen.PetDetail.route,
                arguments = listOf(navArgument("petId") { type = NavType.StringType })
            ) { back ->
                val petId = back.arguments?.getString("petId") ?: return@composable
                PetDetailScreen(vm = vm, petId = petId,
                    onNavigate = { navController.navigate(it) },
                    onBack = { navController.popBackStack() })
            }
            composable(
                "pets/form?petId={petId}",
                arguments = listOf(navArgument("petId") { type = NavType.StringType; nullable = true; defaultValue = null })
            ) { back ->
                PetFormScreen(vm = vm, petId = back.arguments?.getString("petId"),
                    onBack = { navController.popBackStack() })
            }
            composable(Screen.Geofences.route) {
                GeofenceListScreen(vm) { route -> navController.navigate(route) }
            }
            composable(
                "geofences/form?geofenceId={geofenceId}&petId={petId}",
                arguments = listOf(
                    navArgument("geofenceId") { type = NavType.StringType; nullable = true; defaultValue = null },
                    navArgument("petId") { type = NavType.StringType; nullable = true; defaultValue = null }
                )
            ) { back ->
                GeofenceFormScreen(vm = vm,
                    geofenceId = back.arguments?.getString("geofenceId"),
                    preselectedPetId = back.arguments?.getString("petId"),
                    onBack = { navController.popBackStack() })
            }
            composable(
                Screen.GeofenceDetail.route,
                arguments = listOf(navArgument("geofenceId") { type = NavType.StringType })
            ) { back ->
                val geoId = back.arguments?.getString("geofenceId") ?: return@composable
                GeofenceDetailScreen(vm = vm, geofenceId = geoId,
                    onNavigate = { navController.navigate(it) },
                    onBack = { navController.popBackStack() })
            }
            composable(
                "history?petId={petId}",
                arguments = listOf(navArgument("petId") { type = NavType.StringType; nullable = true; defaultValue = null })
            ) { back ->
                LocationHistoryScreen(vm = vm, filterPetId = back.arguments?.getString("petId"),
                    onBack = { navController.popBackStack() })
            }
            composable(Screen.Alerts.route) { AlertsScreen(vm) }
            composable(Screen.ChipControl.route) {
                ChipControlScreen(vm = vm, onBack = { navController.popBackStack() })
            }
            composable(Screen.Profile.route) {
                ProfileScreen(
                    vm = vm,
                    onChangeUser = {
                        navController.navigate(Screen.Login.route) {
                            popUpTo(Screen.Dashboard.route) { inclusive = true }
                        }
                    },
                    onManageUsers = { navController.navigate(Screen.ManageUsers.route) },
                    onChipControl = { navController.navigate(Screen.ChipControl.route) }
                )
            }
        }
    }
}
