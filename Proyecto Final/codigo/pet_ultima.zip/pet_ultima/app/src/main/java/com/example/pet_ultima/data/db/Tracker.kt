package com.example.pet_ultima.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "trackers")
data class Tracker(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val petId: String,
    val name: String = "GF-07",
    val phoneNumber: String,          // SIM number in the chip
    val chipPassword: String = "123456",
    val isActive: Boolean = true,
    val lastCommand: String = "",
    val lastCommandAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)
