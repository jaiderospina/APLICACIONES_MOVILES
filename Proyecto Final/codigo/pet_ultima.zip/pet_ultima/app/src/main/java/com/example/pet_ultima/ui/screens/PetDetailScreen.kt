package com.example.pet_ultima.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Article
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.pet_ultima.data.db.Pet
import com.example.pet_ultima.navigation.Screen
import com.example.pet_ultima.ui.screens.PetShareDialog
import com.example.pet_ultima.ui.components.speciesEmoji
import com.example.pet_ultima.ui.components.statusColor
import com.example.pet_ultima.ui.components.statusLabel
import com.example.pet_ultima.viewmodel.PetViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PetDetailScreen(vm: PetViewModel, petId: String, onNavigate: (String) -> Unit, onBack: () -> Unit) {
    var pet by remember { mutableStateOf<Pet?>(null) }
    var showDeleteDialog by remember { mutableStateOf(false) }
    var showShareDialog by remember { mutableStateOf(false) }
    var statusExpanded by remember { mutableStateOf(false) }
    val geofences by vm.getGeofencesByPet(petId).collectAsState(initial = emptyList())

    LaunchedEffect(petId) {
        pet = vm.getPetById(petId)
    }
    // Refresh when pets list changes
    val pets by vm.pets.collectAsState()
    LaunchedEffect(pets) {
        pet = vm.getPetById(petId)
    }

    if (showShareDialog) {
        pet?.let {
            PetShareDialog(vm = vm, pet = it, onDismiss = { showShareDialog = false })
        }
    }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("¿Eliminar a ${pet?.name}?") },
            text = { Text("Esta acción no se puede deshacer.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.deletePet(petId)
                    onBack()
                }, colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)) {
                    Text("Eliminar")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) { Text("Cancelar") }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(pet?.name ?: "") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Volver") }
                },
                actions = {
                    IconButton(onClick = { showShareDialog = true }) {
                        Icon(Icons.Default.Share, "Compartir")
                    }
                    IconButton(onClick = { onNavigate(Screen.PetForm.createRoute(petId)) }) {
                        Icon(Icons.Default.Edit, "Editar")
                    }
                    IconButton(onClick = { showDeleteDialog = true }) {
                        Icon(Icons.Default.Delete, "Eliminar", tint = MaterialTheme.colorScheme.error)
                    }
                }
            )
        }
    ) { padding ->
        val p = pet
        if (p == null) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Photo + header
            Card(shape = RoundedCornerShape(20.dp)) {
                Column {
                    Box(
                        modifier = Modifier.fillMaxWidth().height(180.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        if (p.photoUri.isNotBlank()) {
                            AsyncImage(
                                model = p.photoUri,
                                contentDescription = p.name,
                                modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Surface(
                                modifier = Modifier.fillMaxSize(),
                                color = MaterialTheme.colorScheme.primaryContainer,
                                shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(speciesEmoji(p.species), fontSize = 64.sp)
                                }
                            }
                        }
                    }
                    Row(
                        modifier = Modifier.padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(p.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                            Text(p.species.replaceFirstChar { it.uppercase() }, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        // Status selector
                        ExposedDropdownMenuBox(expanded = statusExpanded, onExpandedChange = { statusExpanded = it }) {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = statusColor(p.status, MaterialTheme.colorScheme).copy(alpha = 0.12f),
                                modifier = Modifier.menuAnchor()
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        statusLabel(p.status),
                                        color = statusColor(p.status, MaterialTheme.colorScheme),
                                        fontWeight = FontWeight.Medium
                                    )
                                    Icon(Icons.Default.ArrowDropDown, null, modifier = Modifier.size(16.dp), tint = statusColor(p.status, MaterialTheme.colorScheme))
                                }
                            }
                            ExposedDropdownMenu(expanded = statusExpanded, onDismissRequest = { statusExpanded = false }) {
                                listOf("active" to "✅ Activo", "lost" to "🔴 Perdido", "found" to "🟢 Encontrado", "inactive" to "⚪ Inactivo").forEach { (val_, label) ->
                                    DropdownMenuItem(
                                        text = { Text(label) },
                                        onClick = {
                                            vm.updatePet(p.copy(status = val_))
                                            statusExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Info grid
            val infoItems = buildList {
                if (p.breed.isNotBlank()) add(Triple(Icons.AutoMirrored.Filled.Article, "Raza", p.breed))
                if (p.age != null) add(Triple(Icons.Default.Schedule, "Edad", "${p.age} años"))
                if (p.weight != null) add(Triple(Icons.Default.FitnessCenter, "Peso", "${p.weight} kg"))
                if (p.color.isNotBlank()) add(Triple(Icons.Default.Palette, "Color", p.color))
                if (p.microchipId.isNotBlank()) add(Triple(Icons.Default.Tag, "Microchip", p.microchipId))
            }

            if (infoItems.isNotEmpty()) {
                Card(shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Información", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleSmall)
                        Spacer(Modifier.height(12.dp))
                        infoItems.chunked(2).forEach { row ->
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                row.forEach { (icon, label, value) ->
                                    InfoItem(icon = icon, label = label, value = value, modifier = Modifier.weight(1f))
                                }
                                if (row.size == 1) Spacer(Modifier.weight(1f))
                            }
                            if (infoItems.chunked(2).last() != row) Spacer(Modifier.height(12.dp))
                        }
                    }
                }
            }

            if (p.notes.isNotBlank()) {
                Card(shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Notas", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleSmall)
                        Spacer(Modifier.height(8.dp))
                        Text(p.notes, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            // Quick links
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(
                    onClick = { onNavigate(Screen.LocationHistory.createRoute(petId)) },
                    modifier = Modifier.weight(1f).height(48.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.LocationOn, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Historial")
                }
                OutlinedButton(
                    onClick = { onNavigate(Screen.GeofenceForm.createRoute(petId = petId)) },
                    modifier = Modifier.weight(1f).height(48.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.Shield, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Geocercas (${geofences.size})")
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(
                    onClick = { showShareDialog = true },
                    modifier = Modifier.weight(1f).height(48.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.Share, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(if (p.isShared) "Compartida ✓" else "Compartir")
                }
                if (p.chipPhoneNumber.isNotBlank()) {
                    Button(
                        onClick = { onNavigate(Screen.ChipControl.route) },
                        modifier = Modifier.weight(1f).height(48.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary)
                    ) {
                        Icon(Icons.Default.Sensors, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Control GF-07")
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
fun InfoItem(icon: ImageVector, label: String, value: String, modifier: Modifier = Modifier) {
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Surface(shape = RoundedCornerShape(8.dp), color = MaterialTheme.colorScheme.secondaryContainer, modifier = Modifier.size(32.dp)) {
            Box(contentAlignment = Alignment.Center) {
                Icon(icon, null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSecondaryContainer)
            }
        }
        Column {
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
        }
    }
}
