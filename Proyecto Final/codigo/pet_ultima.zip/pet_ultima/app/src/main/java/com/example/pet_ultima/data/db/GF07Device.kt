package com.example.pet_ultima.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "gf07_devices")
data class Gf07Device(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val petId: String,
    val phoneNumber: String,          // SIM number of the chip
    val password: String = "123456",  // GF-07 command password (default 123456)
    val alias: String = "",
    val lastResponse: String = "",
    val lastResponseAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)
